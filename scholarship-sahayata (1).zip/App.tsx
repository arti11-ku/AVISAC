
import React, { useState } from 'react';
import Header from './components/Header';
import Navbar from './components/Navbar';
import Slider from './components/Slider';
import AccessibilityWidget from './components/AccessibilityWidget';
import Footer from './components/Footer';
import SchemesAndNews from './components/SchemesAndNews';
import AboutPage from './components/AboutPage';
import ChatBot from './components/ChatBot';
import { LanguageCode } from './types';
import { PAGE_CONTENT, LANGUAGES } from './constants';
import { AlertCircle } from 'lucide-react';

const App: React.FC = () => {
  // Global State for Language and Route Path
  const [currentLang, setCurrentLang] = useState<LanguageCode>('en');
  const [isAccessWidgetOpen, setAccessWidgetOpen] = useState(false);
  const [currentPath, setCurrentPath] = useState('/');

  // Simplified Client-Side Router
  // Updates state to switch views and scrolls to top
  const handleNavigate = (path: string) => {
    if (path === '/events') {
      setCurrentPath('/');
      // Wait for DOM update if switching pages
      setTimeout(() => {
        const element = document.getElementById('events-section');
        if (element) {
          element.scrollIntoView({ behavior: 'smooth' });
        }
      }, 100);
    } else {
      setCurrentPath(path);
      window.scrollTo(0, 0);
    }
  };

  // Renders the main content based on the current path
  const renderContent = () => {
    // Home Page View
    if (currentPath === '/') {
      return (
        <>
          <Slider />
          <SchemesAndNews currentLang={currentLang} onNavigate={handleNavigate} />
        </>
      );
    }

    // Content Pages (About, Schemes Details, News Details)
    if (PAGE_CONTENT[currentPath]) {
        const hasTranslation = !!PAGE_CONTENT[currentPath][currentLang];
        // Select content based on language, fallback to English if translation missing
        const pageData = PAGE_CONTENT[currentPath][currentLang] || PAGE_CONTENT[currentPath]['en'];
        const { title, content } = pageData;
        
        const langName = LANGUAGES.find(l => l.code === currentLang)?.name || currentLang;

        return (
          <>
            {/* Banner if translation is missing */}
            {!hasTranslation && currentLang !== 'en' && (
              <div className="bg-yellow-50 border-l-4 border-yellow-400 p-4 container mx-auto mt-6">
                <div className="flex items-center">
                  <div className="flex-shrink-0">
                    <AlertCircle className="h-5 w-5 text-yellow-400" aria-hidden="true" />
                  </div>
                  <div className="ml-3">
                    <p className="text-sm text-yellow-700">
                      We are currently translating this content into <span className="font-bold">{langName}</span>. Displaying English version below.
                    </p>
                  </div>
                </div>
              </div>
            )}
            <AboutPage title={title} content={content} />
          </>
        );
    }

    // Fallback for 404 / Unhandled Routes
    return (
        <div className="container mx-auto px-4 py-20 text-center min-h-[50vh] flex flex-col items-center justify-center">
            <h2 className="text-2xl text-gray-600 mb-4">Page Content for {currentPath}</h2>
            <p className="text-gray-500 mb-6">This page is currently under construction.</p>
            <button onClick={() => handleNavigate('/')} className="bg-tiranga-blue text-white px-6 py-2 rounded hover:bg-blue-900 transition-colors">Go Home</button>
        </div>
    );
  };

  return (
    <div className="min-h-screen flex flex-col font-sans text-gray-900">
      <AccessibilityWidget 
        isOpen={isAccessWidgetOpen} 
        onClose={() => setAccessWidgetOpen(false)} 
      />
      
      <Header 
        currentLang={currentLang} 
        setLang={setCurrentLang} 
        toggleAccessibility={() => setAccessWidgetOpen(!isAccessWidgetOpen)} 
      />
      
      <Navbar onNavigate={handleNavigate} currentLang={currentLang} />
      
      <main className="flex-grow bg-gray-50">
        {renderContent()}
      </main>
      
      <Footer currentLang={currentLang} />

      {/* Chat Assistant Widget - Passing currentLang to enable dynamic language switching */}
      <ChatBot currentLang={currentLang} />
    </div>
  );
};

export default App;
