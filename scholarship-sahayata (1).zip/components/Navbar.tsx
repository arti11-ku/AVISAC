import React, { useState } from 'react';
import { NavItem, LanguageCode } from '../types';
import { NAV_ITEMS, NAV_TRANSLATIONS } from '../constants';
import { Menu, X, ChevronDown } from 'lucide-react';

interface NavbarProps {
  onNavigate: (path: string) => void;
  currentLang?: LanguageCode;
}

const Navbar: React.FC<NavbarProps> = ({ onNavigate, currentLang = 'en' }) => {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [activeDropdown, setActiveDropdown] = useState<string | null>(null);

  // Handle clicks on nav items: prevent default href link, use client-side router
  const handleNavClick = (e: React.MouseEvent, path: string) => {
    e.preventDefault();
    onNavigate(path);
    setIsMobileMenuOpen(false);
  };

  // Helper to translate top-level navigation labels based on current language
  const getLabel = (label: string) => {
    if (currentLang === 'en') return label;
    return NAV_TRANSLATIONS[label]?.[currentLang] || label;
  };

  return (
    <nav className="bg-tiranga-blue text-white sticky top-0 z-40 shadow-lg border-t-4 border-tiranga-saffron border-b-4 border-tiranga-green">
      <div className="w-full px-4 md:px-8 lg:px-12">
        <div className="flex items-center justify-between h-14">
          {/* Mobile Menu Toggle Button */}
          <button 
            className="md:hidden p-1 hover:bg-white/10 rounded"
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          >
            {isMobileMenuOpen ? <X size={28} /> : <Menu size={28} />}
          </button>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center space-x-2 h-full w-full justify-center">
            {NAV_ITEMS.map((item) => (
              <div 
                key={item.label} 
                className="relative group h-full flex items-center"
                onMouseEnter={() => setActiveDropdown(item.label)}
                onMouseLeave={() => setActiveDropdown(null)}
              >
                {item.children ? (
                  // Dropdown Trigger
                  <button className={`px-5 py-2 text-base font-medium rounded flex items-center gap-1 transition-colors h-full ${activeDropdown === item.label ? 'bg-white/20' : 'hover:bg-white/10'}`}>
                    {getLabel(item.label)}
                    <ChevronDown size={16} />
                  </button>
                ) : (
                  // Simple Link
                  <a 
                    href={item.path}
                    onClick={(e) => item.path && handleNavClick(e, item.path)}
                    className="px-5 py-2 text-base font-medium hover:bg-white/10 rounded transition-colors h-full flex items-center"
                  >
                    {getLabel(item.label)}
                  </a>
                )}

                {/* Desktop Dropdown Menu */}
                {item.children && (
                  <div className="absolute top-full left-0 w-64 bg-white text-gray-800 shadow-xl rounded-b-lg overflow-hidden hidden group-hover:block animate-fade-in border-t-4 border-tiranga-saffron border-b-4 border-tiranga-green">
                    {item.children.map((child) => (
                      <a 
                        key={child.label}
                        href={child.path}
                        onClick={(e) => child.path && handleNavClick(e, child.path)}
                        className="block px-5 py-3 text-base hover:bg-orange-50 border-b border-gray-100 last:border-none hover:text-tiranga-saffron transition-colors"
                      >
                        {/* Sub-menu translation skipped for brevity */}
                        {child.label}
                      </a>
                    ))}
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Mobile Navigation Menu (Visible only on small screens) */}
        {isMobileMenuOpen && (
          <div className="md:hidden py-3 bg-blue-900 border-t border-blue-800">
            {NAV_ITEMS.map((item) => (
              <div key={item.label}>
                {item.children ? (
                  <div className="px-5 py-3 text-base font-medium text-gray-200 border-b border-blue-800">
                    <span className="block mb-1 text-tiranga-saffron">{getLabel(item.label)}</span>
                    <div className="pl-4 space-y-1 border-l-2 border-tiranga-green ml-1">
                      {item.children.map(child => (
                        <a 
                            key={child.label} 
                            href={child.path} 
                            onClick={(e) => child.path && handleNavClick(e, child.path)}
                            className="block py-2 hover:text-white"
                        >
                            {child.label}
                        </a>
                      ))}
                    </div>
                  </div>
                ) : (
                  <a 
                    href={item.path} 
                    onClick={(e) => item.path && handleNavClick(e, item.path)}
                    className="block px-5 py-3 text-base font-medium text-white hover:bg-blue-800 border-b border-blue-800"
                  >
                    {getLabel(item.label)}
                  </a>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    </nav>
  );
};

export default Navbar;