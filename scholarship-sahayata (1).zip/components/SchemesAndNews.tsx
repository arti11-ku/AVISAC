import React from 'react';
import { Calendar, ArrowRight, ExternalLink, FileText } from 'lucide-react';
import { SCHEMES, NEWS_ITEMS, DICTIONARY } from '../constants';
import { LanguageCode } from '../types';

interface Props {
  currentLang: LanguageCode;
  onNavigate: (path: string) => void;
}

const SchemesAndNews: React.FC<Props> = ({ currentLang, onNavigate }) => {
  const t = DICTIONARY[currentLang] || DICTIONARY['en'];

  return (
    <section className="py-14 bg-white" id="content">
      <div className="container mx-auto px-4">
        <div className="flex flex-col lg:flex-row gap-8">
          
          {/* News Section - Left Column */}
          <div className="w-full lg:w-1/3" id="events-section">
            <div className="bg-white rounded-lg shadow-lg border border-gray-100 h-full overflow-hidden flex flex-col">
              
              {/* News Header */}
              <div className="p-5 bg-tiranga-blue text-white flex justify-between items-center shadow-sm">
                <h3 className="text-xl font-bold flex items-center gap-2">
                  <Calendar size={24} className="text-tiranga-saffron" />
                  {t.newsTitle}
                </h3>
                <button onClick={() => onNavigate('/events')} className="text-sm text-white/80 hover:text-white hover:underline bg-white/10 px-3 py-1 rounded transition-colors">{t.viewAll}</button>
              </div>
              
              {/* Scrollable News List */}
              <div className="h-[500px] overflow-y-auto bg-gray-50 relative">
                <ul className="divide-y divide-gray-200">
                  {NEWS_ITEMS.map((news) => (
                    <li key={news.id} className="hover:bg-blue-50 transition-colors duration-200">
                      <button 
                        onClick={() => onNavigate(`/news/${news.id}`)}
                        className="group block p-5 w-full text-left"
                      >
                        <div className="flex items-start gap-4">
                            {/* Date Box */}
                            <div className="bg-white border border-gray-200 rounded p-1.5 text-center min-w-[60px]">
                                <span className="block text-xl font-bold text-tiranga-saffron leading-none">{news.date.split(' ')[0]}</span>
                                <span className="block text-xs uppercase text-gray-500 font-bold mt-1">{news.date.split(' ')[1]}</span>
                            </div>
                            {/* News Title */}
                            <div>
                                <span className="text-base text-gray-800 group-hover:text-tiranga-blue font-medium leading-snug block">
                                {news.title}
                                </span>
                                <span className="text-xs text-green-700 mt-2 inline-block bg-green-50 px-2 py-0.5 rounded border border-green-100 font-semibold">New Update</span>
                            </div>
                        </div>
                      </button>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </div>

          {/* Schemes Section - Right Column */}
          <div className="w-full lg:w-2/3">
            <div className="flex items-center gap-3 mb-8 pb-2 border-b border-gray-100">
                <div className="w-2 h-10 bg-gradient-to-b from-tiranga-saffron via-white to-tiranga-green border border-gray-200"></div>
              <h3 className="text-3xl font-bold text-gray-800">
                {t.schemesTitle}
              </h3>
            </div>
            
            {/* Schemes Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {SCHEMES.map((scheme) => (
                <a 
                  key={scheme.id} 
                  href={`/scheme/${scheme.id}`}
                  onClick={(e) => {
                    e.preventDefault();
                    onNavigate(`/scheme/${scheme.id}`);
                  }}
                  className="relative bg-white p-7 rounded-lg shadow-sm hover:shadow-xl border border-gray-100 transition-all group flex flex-col h-full overflow-hidden cursor-pointer"
                >
                    {/* Decorative Tiranga stripe */}
                    <div className="absolute left-0 top-0 bottom-0 w-1.5 bg-gradient-to-b from-tiranga-saffron via-white to-tiranga-green opacity-70 group-hover:opacity-100"></div>
                    
                  <div className="flex justify-between items-start mb-4 pl-2">
                    <div className="p-2.5 bg-blue-50 rounded-full text-tiranga-blue group-hover:bg-tiranga-saffron group-hover:text-white transition-colors">
                        <FileText size={24} />
                    </div>
                    <ExternalLink size={20} className="text-gray-400 group-hover:text-tiranga-green transition-colors" />
                  </div>

                  <h4 className="font-bold text-xl text-gray-800 group-hover:text-tiranga-blue mb-3 pl-2 transition-colors">
                    {scheme.title}
                  </h4>
                  <p className="text-base text-gray-600 mb-5 flex-grow pl-2 leading-relaxed">
                    {scheme.description}
                  </p>
                  
                  <div className="pl-2 mt-auto">
                    <span className="text-sm font-bold text-tiranga-blue uppercase tracking-wide flex items-center gap-2 group-hover:text-tiranga-saffron transition-colors">
                        Read More <ArrowRight size={14} />
                    </span>
                  </div>
                </a>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default SchemesAndNews;