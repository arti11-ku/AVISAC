import React, { useState, useEffect } from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';

const SLIDES = [
  {
    id: 1,
    url: 'https://placehold.co/1200x800/png?text=Village+Awareness+Cartoon',
    alt: 'Village Awareness Campaign - Aadhaar Linked vs DBT Enabled',
    caption: 'Empowering Rural Citizens: Understanding DBT Enabled Aadhaar Seeded Accounts'
  },
  {
    id: 2,
    url: 'https://placehold.co/1200x800/png?text=Student+Awareness+Cartoon',
    alt: 'Classroom Education Session on DBT',
    caption: 'Enhancing Student Awareness: Aadhaar Linked vs. DBT Enabled Bank Accounts'
  },
  {
    id: 3,
    url: 'https://placehold.co/1200x800/png?text=Outdoor+Photo+(Hindi+Sign)',
    alt: 'Outdoor Awareness Session',
    caption: 'Campaign: Making Bank Accounts DBT-Ready for Scholarships'
  }
];

const Slider: React.FC = () => {
  const [current, setCurrent] = useState(0);

  // Auto-rotate slides every 5 seconds
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrent((prev) => (prev === SLIDES.length - 1 ? 0 : prev + 1));
    }, 5000);
    return () => clearInterval(timer);
  }, []);

  // Navigation handlers
  const next = () => setCurrent((prev) => (prev === SLIDES.length - 1 ? 0 : prev + 1));
  const prev = () => setCurrent((prev) => (prev === 0 ? SLIDES.length - 1 : prev - 1));

  return (
    <div className="relative w-full h-[350px] md:h-[550px] lg:h-[650px] bg-gray-100 overflow-hidden group border-b-4 border-white">
      {/* Slides Container with Translation Effect */}
      <div 
        className="flex transition-transform duration-700 ease-out h-full"
        style={{ transform: `translateX(-${current * 100}%)` }}
      >
        {SLIDES.map((slide) => (
          <div key={slide.id} className="w-full flex-shrink-0 relative flex items-center justify-center bg-gray-200">
            <img 
              src={slide.url} 
              alt={slide.alt} 
              className="w-full h-full object-contain"
            />
            {/* Caption Overlay with Gradient */}
            <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-tiranga-blue/95 via-tiranga-blue/60 to-transparent p-6 md:p-10 text-white">
              <div className="container mx-auto">
                <div className="border-l-4 border-tiranga-saffron pl-5">
                  <h3 className="text-xl md:text-3xl lg:text-4xl font-bold drop-shadow-md mb-2">{slide.caption}</h3>
                  <p className="text-sm md:text-base lg:text-lg text-gray-200 opacity-90">Department of Social Justice & Empowerment</p>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Navigation Arrows (Hidden by default, visible on hover) */}
      <button onClick={prev} className="absolute left-4 top-1/2 -translate-y-1/2 bg-tiranga-blue/50 hover:bg-tiranga-saffron text-white p-4 rounded-full transition-all opacity-0 group-hover:opacity-100 backdrop-blur-sm border border-white/20">
        <ChevronLeft size={28} />
      </button>

      <button onClick={next} className="absolute right-4 top-1/2 -translate-y-1/2 bg-tiranga-blue/50 hover:bg-tiranga-saffron text-white p-4 rounded-full transition-all opacity-0 group-hover:opacity-100 backdrop-blur-sm border border-white/20">
        <ChevronRight size={28} />
      </button>
      
      {/* Dot Indicators */}
      <div className="absolute bottom-8 right-8 flex gap-3 z-10">
        {SLIDES.map((_, idx) => (
          <button 
            key={idx}
            onClick={() => setCurrent(idx)}
            className={`w-4 h-4 rounded-full transition-colors shadow-sm border border-white/30 ${current === idx ? 'bg-tiranga-saffron scale-110' : 'bg-white/60 hover:bg-white'}`}
          />
        ))}
      </div>
    </div>
  );
};

export default Slider;