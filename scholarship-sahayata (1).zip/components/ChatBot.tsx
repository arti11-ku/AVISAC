
import React, { useState, useRef, useEffect } from 'react';
import { X, Send, Bot, Minimize2 } from 'lucide-react';
import { GoogleGenAI, Chat } from "@google/genai";
import { LanguageCode } from '../types';
import { LANGUAGES } from '../constants';

// Interface for chat message structure
interface Message {
  id: string;
  text: string;
  sender: 'user' | 'bot';
  timestamp: Date;
}

interface ChatBotProps {
  currentLang: LanguageCode;
}

// Localized welcome messages
const WELCOME_MSGS: Record<string, string> = {
  en: "Namaste! I am your virtual assistant. How can I help you with scholarships or schemes today?",
  hi: "नमस्ते! मैं आपका आभासी सहायक हूं। मैं आज छात्रवृत्ति या योजनाओं में आपकी क्या मदद कर सकता हूं?",
  bn: "নমস্কার! আমি আপনার ভার্চুয়াল সহকারী। স্কলারশিপ বা স্কিম নিয়ে আমি আপনাকে কীভাবে সাহায্য করতে পারি?",
  te: "నమస్తే! నేను మీ వర్చువల్ అసిస్టెంట్‌ని. స్కాలర్‌షిప్‌లు లేదా పథకాల గురించి నేను మీకు ఎలా సహాయం చేయగలను?",
  ta: "வணக்கம்! நான் உங்கள் மெய்நிகர் உதவியாளர். உதவித்தொகை அல்லது திட்டங்கள் குறித்து நான் உங்களுக்கு எவ்வாறு உதவ முடியும்?",
};

const ChatBot: React.FC<ChatBotProps> = ({ currentLang }) => {
  // State for managing chat visibility
  const [isOpen, setIsOpen] = useState(false);
  // State for input field text
  const [input, setInput] = useState('');
  // State for storing chat history
  const [messages, setMessages] = useState<Message[]>([]);
  // State for typing indicator
  const [isTyping, setIsTyping] = useState(false);
  // Ref for auto-scrolling to latest message
  const messagesEndRef = useRef<HTMLDivElement>(null);
  // State for the Gemini chat session instance
  const [chatSession, setChatSession] = useState<Chat | null>(null);

  // Helper to get full language name
  const getLangName = (code: string) => {
    const lang = LANGUAGES.find(l => l.code === code);
    return lang ? lang.name : 'English';
  };

  // Effect: Initialize or Re-initialize Gemini Chat when language changes
  useEffect(() => {
    const initChat = async () => {
      try {
        // Check for API Key existence (handled by environment)
        if (process.env.API_KEY) {
          const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
          
          const targetLanguage = getLangName(currentLang);
          
          // System instruction tailored to the current language and single-word handling
          const systemPrompt = `
            You are 'Sahayak', a helpful assistant for the Department of Social Justice & Empowerment portal (Scholarship Sahayata). 
            
            CRITICAL RULES:
            1. LANGUAGE: You MUST answer in ${targetLanguage}. If the user asks in a different language, answer in that language but prioritize ${targetLanguage}.
            2. CONTEXT: Answer questions about scholarships (Post-Matric, Pre-Matric), DBT (Direct Benefit Transfer), senior citizens, and social welfare schemes.
            3. SINGLE WORD INPUTS: If the user types a single word (e.g., "Scholarship", "Money", "Login", "DBT"), DO NOT say "How can I help?". Instead, provide a brief definition or summary of that topic related to this portal and offer specific help.
               - Example: If user types "DBT", reply: "DBT stands for Direct Benefit Transfer. It ensures scholarship money goes directly to your Aadhaar-seeded bank account. Do you want to know how to link Aadhaar?"
            4. LIMITATION: Do not access personal data. If asked for status, guide them to the 'State Nodal Offices' page.
            5. TONE: Be polite, official yet accessible.
          `;

          const chat = ai.chats.create({
            model: 'gemini-2.5-flash',
            config: {
              systemInstruction: systemPrompt,
            }
          });
          setChatSession(chat);

          // Reset conversation with a welcome message in the new language
          const welcomeText = WELCOME_MSGS[currentLang] || WELCOME_MSGS['en'] || WELCOME_MSGS['hi'];
          setMessages([{
            id: 'init',
            text: welcomeText,
            sender: 'bot',
            timestamp: new Date()
          }]);
        }
      } catch (e) {
        console.error("Failed to initialize Gemini Chat:", e);
      }
    };

    initChat();
  }, [currentLang]); // Re-run when language changes

  // Helper function to scroll chat view to the bottom
  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  // Effect: Auto-scroll whenever messages change or chat opens
  useEffect(() => {
    scrollToBottom();
  }, [messages, isOpen]);

  // Handler for sending a message
  const handleSend = async () => {
    if (!input.trim()) return;

    const userText = input;
    const userMsg: Message = {
      id: Date.now().toString(),
      text: userText,
      sender: 'user',
      timestamp: new Date()
    };

    // Update UI with user message
    setMessages(prev => [...prev, userMsg]);
    setInput('');
    setIsTyping(true);

    try {
      if (chatSession) {
        // Call Gemini API with streaming response
        const result = await chatSession.sendMessageStream({ message: userText });
        
        // Create a temporary bot message for streaming content
        const botMsgId = (Date.now() + 1).toString();
        setMessages(prev => [...prev, {
            id: botMsgId,
            text: "", // Start empty
            sender: 'bot',
            timestamp: new Date()
        }]);

        let accumulatedText = "";
        
        // Iterate through the stream chunks
        for await (const chunk of result) {
            const text = chunk.text;
            if (text) {
                accumulatedText += text;
                // Update the specific bot message with new text
                setMessages(prev => prev.map(m => 
                    m.id === botMsgId ? { ...m, text: accumulatedText } : m
                ));
            }
        }
      } else {
        // Fallback logic if API is not available
        setTimeout(() => {
          setMessages(prev => [...prev, {
            id: (Date.now() + 1).toString(),
            text: "I am currently running in demo mode. Please check the 'Major Schemes' section for more information.",
            sender: 'bot',
            timestamp: new Date()
          }]);
        }, 1000);
      }
    } catch (error) {
      console.error("Chat interaction error:", error);
      setMessages(prev => [...prev, {
        id: (Date.now() + 1).toString(),
        text: "I'm sorry, I encountered an error connecting to the server. Please try again.",
        sender: 'bot',
        timestamp: new Date()
      }]);
    } finally {
      setIsTyping(false);
    }
  };

  // Handle Enter key to send
  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  return (
    <>
      {/* Floating Action Button (FAB) - Tri-colour Theme */}
      <button
        onClick={() => setIsOpen(!isOpen)}
        className={`fixed bottom-6 right-6 z-50 p-4 rounded-full shadow-2xl transition-all duration-300 hover:scale-110 border-4 border-white flex items-center justify-center ${
            // Tricolour Gradient using specific Hex Codes for Saffron, White, Green
            isOpen ? 'bg-gray-800 rotate-90' : 'bg-gradient-to-br from-[#FF9933] via-[#FFFFFF] to-[#138808]'
        }`}
        aria-label="Toggle Chat Assistant"
        title="Chat with Sahayak"
      >
        {/* Icon color is dark blue (Ashok Chakra) for contrast */}
        {isOpen ? <X size={32} className="text-white" /> : <Bot size={32} className="text-[#000080] drop-shadow-md" />}
      </button>

      {/* Chat Window Container - Enlarged Size */}
      <div
        className={`fixed bottom-28 right-6 z-40 w-[360px] md:w-[450px] bg-white rounded-2xl shadow-2xl border-2 border-white transform transition-all duration-300 origin-bottom-right flex flex-col overflow-hidden font-sans ${
          isOpen ? 'scale-100 opacity-100 translate-y-0' : 'scale-0 opacity-0 translate-y-10 pointer-events-none'
        }`}
        style={{ height: '600px', maxHeight: '85vh' }}
      >
        {/* Chat Header */}
        <div className="bg-gradient-to-r from-[#000080] to-blue-900 p-4 flex justify-between items-center text-white shadow-md relative z-20">
          <div className="flex items-center gap-3">
            <div className="bg-white/20 p-2 rounded-full backdrop-blur-sm border border-white/10">
                <Bot size={24} />
            </div>
            <div>
                <h3 className="font-bold text-lg tracking-wide">Sahayak Assistant</h3>
                <div className="flex items-center gap-1.5">
                    <span className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></span>
                    <span className="text-xs text-green-100 font-medium opacity-90">
                       {LANGUAGES.find(l => l.code === currentLang)?.name.split('(')[0] || 'English'} Mode
                    </span>
                </div>
            </div>
          </div>
          <button 
            onClick={() => setIsOpen(false)} 
            className="hover:bg-white/20 p-2 rounded-full transition-colors"
            aria-label="Minimize Chat"
          >
            <Minimize2 size={20} />
          </button>
        </div>

        {/* Messages Scrollable Area with Internal Tri-colour Gradient */}
        <div 
          className="flex-1 overflow-y-auto p-5 space-y-5 custom-scrollbar"
          style={{
            // Saffron tint at top -> White middle -> Green tint at bottom
            background: 'linear-gradient(180deg, rgba(255, 153, 51, 0.12) 0%, rgba(255, 255, 255, 1) 40%, rgba(255, 255, 255, 1) 60%, rgba(19, 136, 8, 0.12) 100%)'
          }}
        >
          {/* Welcome timestamp */}
          <div className="text-center">
            <span className="text-[11px] text-gray-500 bg-white/80 backdrop-blur-sm border border-gray-200 px-3 py-1 rounded-full font-medium shadow-sm">Today</span>
          </div>

          {messages.map((msg) => (
            <div
              key={msg.id}
              className={`flex ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              {/* Avatar for Bot */}
              {msg.sender === 'bot' && (
                 <div className="w-8 h-8 rounded-full bg-white border border-gray-200 shadow-sm flex items-center justify-center mr-3 flex-shrink-0 mt-1">
                    <img src="https://upload.wikimedia.org/wikipedia/commons/5/55/Emblem_of_India.svg" alt="Bot" className="w-5 h-5 opacity-80" />
                 </div>
              )}

              {/* Message Bubble */}
              <div
                className={`max-w-[85%] p-4 rounded-2xl text-[15px] shadow-sm leading-relaxed whitespace-pre-wrap ${
                  msg.sender === 'user'
                    ? 'bg-[#000080] text-white rounded-br-none'
                    : 'bg-white/95 text-gray-800 border border-gray-200 rounded-bl-none backdrop-blur-sm'
                }`}
              >
                {msg.text}
              </div>
            </div>
          ))}

          {/* Typing Animation Indicator */}
          {isTyping && (
            <div className="flex justify-start items-center">
               <div className="w-8 h-8 rounded-full bg-white border border-gray-200 shadow-sm flex items-center justify-center mr-3 flex-shrink-0">
                    <Bot size={16} className="text-gray-400" />
                 </div>
              <div className="bg-white border border-gray-200 p-4 rounded-2xl rounded-bl-none shadow-sm">
                <div className="flex gap-1.5 h-4 items-center">
                  <span className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"></span>
                  <span className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></span>
                  <span className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.4s' }}></span>
                </div>
              </div>
            </div>
          )}
          <div ref={messagesEndRef} />
        </div>

        {/* Input Footer */}
        <div className="p-4 bg-white border-t border-gray-200 relative z-20">
          <div className="flex items-center gap-3 bg-gray-50 rounded-full px-5 py-3 border border-gray-200 focus-within:border-tiranga-blue focus-within:ring-1 focus-within:ring-tiranga-blue transition-all shadow-inner">
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={handleKeyPress}
              placeholder={currentLang === 'hi' ? "यहां पूछें..." : "Ask about schemes..."}
              className="flex-1 bg-transparent outline-none text-base text-gray-700 placeholder-gray-500"
              autoFocus={isOpen}
            />
            <button
              onClick={handleSend}
              disabled={!input.trim() || isTyping}
              className={`p-2.5 rounded-full transition-all flex items-center justify-center ${
                input.trim() 
                  ? 'bg-[#FF9933] text-white shadow-md hover:scale-105 transform' 
                  : 'bg-gray-300 text-gray-500 cursor-not-allowed'
              }`}
              aria-label="Send Message"
            >
              <Send size={18} />
            </button>
          </div>
          <div className="text-[11px] text-center text-gray-400 mt-2 font-medium">
            AI responses may vary. Check official documents.
          </div>
        </div>
      </div>
    </>
  );
};

export default ChatBot;
