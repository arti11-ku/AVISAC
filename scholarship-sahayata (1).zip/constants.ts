import { Language, NavItem, Scheme, LanguageCode } from './types';

// List of all supported languages for the application
export const LANGUAGES: Language[] = [
  { code: 'en', name: 'English' },
  { code: 'hi', name: 'हिन्दी (Hindi)' },
  { code: 'as', name: 'অসমীয়া (Assamese)' },
  { code: 'bn', name: 'বাংলা (Bengali)' },
  { code: 'gu', name: 'ગુજરાતી (Gujarati)' },
  { code: 'kn', name: 'ಕನ್ನಡ (Kannada)' },
  { code: 'ks', name: 'कश्मीरी (Kashmiri)' },
  { code: 'kok', name: 'कोंकणी (Konkani)' },
  { code: 'ml', name: 'മലയാളം (Malayalam)' },
  { code: 'mr', name: 'मराठी (Marathi)' },
  { code: 'ne', name: 'नेपाली (Nepali)' },
  { code: 'or', name: 'ଓଡ଼ିଆ (Odia)' },
  { code: 'pa', name: 'ਪੰਜਾਬੀ (Punjabi)' },
  { code: 'sa', name: 'संस्कृतम् (Sanskrit)' },
  { code: 'sd', name: 'सिंधी (Sindhi)' },
  { code: 'ta', name: 'தமிழ் (Tamil)' },
  { code: 'te', name: 'తెలుగు (Telugu)' },
  { code: 'ur', name: 'اردو (Urdu)' },
  { code: 'mai', name: 'मैथिली (Maithili)' },
  { code: 'doi', name: 'डोगरी (Dogri)' },
  { code: 'brx', name: 'बड़ो (Bodo)' },
  { code: 'sat', name: 'संताली (Santali)' },
];

// Navigation structure including nested dropdowns
export const NAV_ITEMS: NavItem[] = [
  { label: 'Home', path: '/' },
  { 
    label: 'About Us', 
    children: [
      { label: 'About the Ministry', path: '/about/ministry' },
      { label: 'Vision & Mission', path: '/about/vision' },
      { label: 'Organizational Structure', path: '/about/structure' },
      { label: 'Key Schemes & Initiatives', path: '/about/schemes' },
      { label: 'Legislative & Policy Framework', path: '/about/legislation' },
      { label: 'Core Focus Groups', path: '/about/focus-groups' },
    ] 
  },
  {
    label: 'Associated Organisations',
    children: [
      { label: 'NIC (National Informatics Centre)', path: '/associated/nic' },
      { label: 'State Nodal Offices', path: '/associated/state-nodal-offices' },
      { label: 'Help Centres', path: '/associated/help-centres' },
    ]
  },
  { label: 'Events', path: '/events' },
];

// Important helpline numbers displayed in the header
export const HELPLINES = [
  { label: 'National Scholarship Portal Helpline', number: '0120-6619540 (8 AM - 8 PM)' },
  { label: 'NSP Support', number: '011-26172917 / 011-26172949' },
  { label: 'National Helpline Against Atrocities (SC/ST)', number: '18002621980 / 14566' },
];

// List of major schemes displayed on the home page
export const SCHEMES: Scheme[] = [
  {
    id: '1',
    title: 'Post-Matric Scholarship for SC',
    description: 'Financial assistance for SC students studying at post-matriculation or post-secondary stage.',
    link: '#',
  },
  {
    id: '2',
    title: 'Pre-Matric Scholarship for SC',
    description: 'Supporting parents of SC children for education of their wards studying in classes IX and X.',
    link: '#',
  },
  {
    id: '3',
    title: 'National Overseas Scholarship',
    description: 'Financial assistance to selected students for pursuing Master level courses and Ph.D. abroad.',
    link: '#',
  },
  {
    id: '4',
    title: 'SMILE',
    description: 'Support for Marginalized Individuals for Livelihood and Enterprise.',
    link: '#',
  },
  {
    id: '5',
    title: 'Transgender Portal',
    description: 'National portal for Transgender persons to apply for certificates and ID cards.',
    link: '#',
  },
  {
    id: '6',
    title: 'Senior Citizens Welfare',
    description: 'Programmes relating to the welfare of Senior Citizens.',
    link: '#',
  },
];

// News and Events data
export const NEWS_ITEMS = [
  { id: 1, title: 'Applications open for Post-Matric Scholarship 2025-26', date: '12 Dec 2025' },
  { id: 2, title: 'New DBT guidelines released for associated banks', date: '10 Dec 2025' },
  { id: 3, title: 'Awareness camp scheduled in Varanasi regarding PM-AJAY', date: '08 Dec 2025' },
  { id: 4, title: 'Last date extended for National Overseas Scholarship', date: '07 Dec 2025' },
  { id: 5, title: 'SMILE scheme beneficiaries reach new milestone', date: '07 Dec 2025' },
];

// Content Dictionary for Pages (Key = Route Path, Value = Object by Language Code)
// Structure: Path -> Language Code -> { title, content[] }
export const PAGE_CONTENT: Record<string, Record<string, { title: string; content: string[] }>> = {
  '/about/ministry': {
    en: {
      title: 'About the Ministry',
      content: [
        "The Ministry of Social Justice & Empowerment serves as the nodal Ministry of the Government of India for the comprehensive welfare, social justice, and empowerment of society's most vulnerable and marginalized sections. It is entrusted with the critical responsibility of formulating policies, planning initiatives, and coordinating programmes aimed at the upliftment and development of Scheduled Castes, Other Backward Classes, Persons with Disabilities (Divyangjan), Senior Citizens, Transgender persons, and those affected by substance abuse. The Ministry's core objective is to create an inclusive national framework that ensures these communities are brought into the mainstream of development, enabling them to become self-reliant and live with dignity and respect."
      ]
    },
    hi: {
      title: 'मंत्रालय के बारे में',
      content: [
        "सामाजिक न्याय और अधिकारिता मंत्रालय समाज के सबसे कमजोर और सीमांत वर्गों के व्यापक कल्याण, सामाजिक न्याय और सशक्तिकरण के लिए भारत सरकार का नोडल मंत्रालय है। इसे अनुसूचित जातियों, अन्य पिछड़ा वर्गों, विकलांग व्यक्तियों (दिव्यांगजन), वरिष्ठ नागरिकों, ट्रांसजेंडर व्यक्तियों और नशीले पदार्थों के दुरुपयोग से प्रभावित लोगों के उत्थान और विकास के उद्देश्य से नीतियों को बनाने, पहलों की योजना बनाने और कार्यक्रमों के समन्वय की महत्वपूर्ण जिम्मेदारी सौंपी गई है। मंत्रालय का मुख्य उद्देश्य एक समावेशी राष्ट्रीय ढांचा तैयार करना है जो यह सुनिश्चित करे कि इन समुदायों को विकास की मुख्यधारा में लाया जाए, जिससे वे आत्मनिर्भर बन सकें और गरिमा और सम्मान के साथ जी सकें।"
      ]
    }
  },
  '/about/vision': {
    en: {
      title: 'Vision & Mission',
      content: [
        "Our vision is to build an inclusive, equitable, and caring Indian society where all disadvantaged and marginalized individuals can live productive, safe, and dignified lives, free from all forms of discrimination. We are driven by a mission to actively empower these target groups by implementing a multi-pronged strategy focused on their educational, economic, and social development. We are committed to creating a robust, enabling environment by enforcing protective legislation, providing comprehensive rehabilitation services, and delivering targeted financial support and skill development, thereby ensuring that every citizen has equal opportunities to grow and participate fully in the nation's progress."
      ]
    },
    hi: {
      title: 'दृष्टि और मिशन',
      content: [
        "हमारी दृष्टि एक समावेशी, समतामूलक और देखभाल करने वाले भारतीय समाज का निर्माण करना है जहाँ सभी वंचित और सीमांत व्यक्ति भेदभाव के सभी रूपों से मुक्त, उत्पादक, सुरक्षित और गरिमापूर्ण जीवन जी सकें। हम अपने लक्ष्य समूहों को उनके शैक्षिक, आर्थिक और सामाजिक विकास पर केंद्रित बहुआयामी रणनीति को लागू करके सक्रिय रूप से सशक्त बनाने के मिशन से प्रेरित हैं। हम सुरक्षात्मक कानूनों को लागू करके, व्यापक पुनर्वास सेवाएं प्रदान करके, और लक्षित वित्तीय सहायता और कौशल विकास प्रदान करके एक मजबूत, सक्षम वातावरण बनाने के लिए प्रतिबद्ध हैं, जिससे यह सुनिश्चित हो सके कि प्रत्येक नागरिक को बढ़ने और राष्ट्र की प्रगति में पूरी तरह से भाग लेने के समान अवसर मिलें।"
      ]
    }
  },
  '/about/structure': {
    en: {
      title: 'Organizational Structure',
      content: [
        "The Ministry is led at the political level by a Union Cabinet Minister, who provides overall policy direction and is assisted by Ministers of State. The administrative functions are headed by a Secretary to the Government of India. To ensure dedicated focus and specialized management of its vast mandate, the Ministry's work is operationally divided into two distinct departments: the Department of Social Justice and Empowerment (Samajik Nyay aur Adhikarita Vibhag) and the Department of Empowerment of Persons with Disabilities (Divyangjan Sashaktikaran Vibhag). Each department is managed by its own Secretary, overseeing a structured network of bureaus, divisions, autonomous national institutes, finance corporations, and statutory commissions that execute the Ministry's schemes and safeguard the rights of its beneficiaries across the country."
      ]
    },
    hi: {
      title: 'संगठनात्मक संरचना',
      content: [
        "मंत्रालय का नेतृत्व राजनीतिक स्तर पर एक केंद्रीय कैबिनेट मंत्री करते हैं, जो समग्र नीति निर्देश प्रदान करते हैं और राज्य मंत्रियों द्वारा सहायता प्राप्त करते हैं। प्रशासनिक कार्यों का नेतृत्व भारत सरकार के एक सचिव द्वारा किया जाता है। अपने विशाल जनादेश के समर्पित फोकस और विशिष्ट प्रबंधन को सुनिश्चित करने के लिए, मंत्रालय के काम को परिचालन रूप से दो अलग-अलग विभागों में विभाजित किया गया है: सामाजिक न्याय और अधिकारिता विभाग और विकलांग व्यक्तियों के सशक्तिकरण विभाग (दिव्यांगजन)। प्रत्येक विभाग का प्रबंधन अपने स्वयं के सचिव द्वारा किया जाता है, जो ब्यूरो, डिवीजनों, स्वायत्त राष्ट्रीय संस्थानों, वित्त निगमों और वैधानिक आयोगों के एक संरचित नेटवर्क की देखरेख करते हैं जो मंत्रालय की योजनाओं को निष्पादित करते हैं और देश भर में इसके लाभार्थियों के अधिकारों की रक्षा करते हैं।"
      ]
    }
  },
  '/about/schemes': {
    en: {
      title: 'Key Schemes & Initiatives',
      content: [
        "The Ministry of Social Justice & Empowerment translates its vision into reality through a wide array of flagship schemes and national initiatives. For the educational empowerment of Scheduled Castes and Other Backward Classes, it implements comprehensive scholarship programmes, such as the Post-Matric and Pre-Matric Scholarships, as well as the National Overseas Scholarship, to support students in pursuing higher education both in India and abroad. For economic empowerment, schemes like PM-DAKSH provide skill development training to enhance the employability of target groups, while financial corporations offer credit at concessional terms for self-employment. For Persons with Disabilities (Divyangjan), the Accessible India Campaign (Sugamya Bharat Abhiyan) is a landmark initiative to create a barrier-free environment in public infrastructure, transportation, and digital ecosystems. This is complemented by the ADIP scheme, which provides grants for modern assistive aids and appliances. For Senior Citizens, the Atal Vayo Abhyuday Yojana (AVYAY) supports the establishment and maintenance of old age homes and provides other essential services. The Ministry also leads the National Action Plan for Drug Demand Reduction (NAPDDR), a comprehensive program to combat substance abuse through prevention, treatment, and rehabilitation."
      ]
    },
    hi: {
      title: 'प्रमुख योजनाएं और पहल',
      content: [
        "सामाजिक न्याय और अधिकारिता मंत्रालय अपनी दृष्टि को वास्तविकता में बदलने के लिए कई प्रमुख योजनाओं और राष्ट्रीय पहलों के माध्यम से कार्य करता है। अनुसूचित जातियों और अन्य पिछड़ा वर्गों के शैक्षिक सशक्तिकरण के लिए, यह पोस्ट-मैट्रिक और प्री-मैट्रिक छात्रवृत्ति, साथ ही राष्ट्रीय प्रवासी छात्रवृत्ति जैसे व्यापक छात्रवृत्ति कार्यक्रमों को लागू करता है, ताकि छात्रों को भारत और विदेश दोनों में उच्च शिक्षा प्राप्त करने में सहायता मिल सके। आर्थिक सशक्तिकरण के लिए, PM-DAKSH जैसी योजनाएं लक्ष्य समूहों की रोजगार क्षमता को बढ़ाने के लिए कौशल विकास प्रशिक्षण प्रदान करती हैं, जबकि वित्त निगम स्वरोजगार के लिए रियायती शर्तों पर ऋण प्रदान करते हैं। विकलांग व्यक्तियों (दिव्यांगजन) के लिए, सुगम्य भारत अभियान सार्वजनिक बुनियादी ढांचे, परिवहन और डिजिटल पारिस्थितिकी तंत्र में बाधा मुक्त वातावरण बनाने के लिए एक ऐतिहासिक पहल है। वरिष्ठ नागरिकों के लिए, अटल वयो अभ्युदय योजना (AVYAY) वृद्धाश्रमों की स्थापना और रखरखाव का समर्थन करती है। मंत्रालय नशीली दवाओं की मांग में कमी के लिए राष्ट्रीय कार्य योजना (NAPDDR) का भी नेतृत्व करता है।"
      ]
    }
  },
  '/about/legislation': {
    en: {
      title: 'Legislative & Policy Framework',
      content: [
        "The Ministry's actions are firmly rooted in a strong legislative framework designed to protect and uphold the rights of marginalized communities. It is the nodal Ministry for enforcing the Rights of Persons with Disabilities (RPwD) Act, 2016, a comprehensive law that guarantees the rights and entitlements of PwDs and aligns with the UN Convention on the Rights of Persons with Disabilities. It is also responsible for the Maintenance and Welfare of Parents and Senior Citizens Act, 2007, which makes it a legal obligation for children to provide maintenance for their parents and establishes tribunals to ensure this. Furthermore, the Ministry is tasked with implementing critical civil rights legislation, including the Protection of Civil Rights Act, 1955, and the Scheduled Castes and the Scheduled Tribes (Prevention of Atrocities) Act, 1989, which are powerful legal instruments designed to prevent discrimination, untouchability, and atrocities against these communities. The Ministry also oversees the Prohibition of Employment as Manual Scavengers and their Rehabilitation Act, 2013, working to eliminate this inhumane practice and rehabilitate all individuals engaged in it."
      ]
    },
    hi: {
      title: 'विधायी और नीतिगत ढांचा',
      content: [
        "मंत्रालय के कार्य वंचित समुदायों के अधिकारों की रक्षा और उन्हें बनाए रखने के लिए एक मजबूत विधायी ढांचे में निहित हैं। यह विकलांग व्यक्तियों के अधिकार (RPwD) अधिनियम, 2016 को लागू करने के लिए नोडल मंत्रालय है। यह माता-पिता और वरिष्ठ नागरिकों के भरण-पोषण और कल्याण अधिनियम, 2007 के लिए भी जिम्मेदार है। इसके अलावा, मंत्रालय नागरिक अधिकार संरक्षण अधिनियम, 1955 और अनुसूचित जाति और अनुसूचित जनजाति (अत्याचार निवारण) अधिनियम, 1989 सहित महत्वपूर्ण नागरिक अधिकार कानूनों को लागू करने का काम करता है। मंत्रालय हाथ से मैला ढोने वाले कर्मियों के रूप में रोजगार का निषेध और उनका पुनर्वास अधिनियम, 2013 की भी देखरेख करता है।"
      ]
    }
  },
  '/about/focus-groups': {
    en: {
      title: 'Our Core Focus Groups',
      content: [
        "All policies, schemes, and programmes of the Ministry of Social Justice & Empowerment are directed towards the welfare and empowerment of the nation's most disadvantaged populations. Our primary focus is on ensuring the holistic development of Scheduled Castes (SCs) and Other Backward Classes (OBCs) through targeted educational and economic interventions. We are the central Ministry responsible for the empowerment and inclusion of Persons with Disabilities (Divyangjan), working to ensure their full participation in society. We are also committed to the dignity and well-being of our Senior Citizens, providing them with social security and healthcare support. Our mandate extends to the empowerment of Transgender Persons, safeguarding their rights and facilitating their inclusion into the mainstream. Additionally, we address the welfare of De-notified, Nomadic, and Semi-Nomadic Tribes (DNTs) and lead the nation's efforts in the rehabilitation of Victims of Substance Abuse, ensuring that every section of society has the support and opportunity to thrive."
      ]
    },
    hi: {
      title: 'हमारे मुख्य फोकस समूह',
      content: [
        "सामाजिक न्याय और अधिकारिता मंत्रालय की सभी नीतियां, योजनाएं और कार्यक्रम देश की सबसे वंचित आबादी के कल्याण और सशक्तिकरण की ओर निर्देशित हैं। हमारा प्राथमिक ध्यान लक्षित शैक्षिक और आर्थिक हस्तक्षेपों के माध्यम से अनुसूचित जातियों (SCs) और अन्य पिछड़ा वर्गों (OBCs) के समग्र विकास को सुनिश्चित करने पर है। हम विकलांग व्यक्तियों (दिव्यांगजन) के सशक्तिकरण और समावेशन के लिए जिम्मेदार केंद्रीय मंत्रालय हैं। हम अपने वरिष्ठ नागरिकों की गरिमा और कल्याण के लिए भी प्रतिबद्ध हैं। हमारा जनादेश ट्रांसजेंडर व्यक्तियों के सशक्तिकरण, उनके अधिकारों की रक्षा और मुख्यधारा में उनके समावेशन की सुविधा तक फैला हुआ है। इसके अतिरिक्त, हम विमुक्त, घुमंतू और अर्ध-घुमंतू जनजातियों (DNTs) के कल्याण को संबोधित करते हैं और नशीले पदार्थों के दुरुपयोग के पीड़ितों के पुनर्वास में राष्ट्र के प्रयासों का नेतृत्व करते हैं।"
      ]
    }
  },
  '/associated/nic': {
    en: {
      title: 'NIC (National Informatics Centre)',
      content: [
        "This page lists the technical contacts for the website portal itself. The National Informatics Centre (NIC), operating under the Ministry of Electronics and Information Technology (MeitY), serves as the primary technology partner for the Indian government. They are responsible for designing, developing, hosting, and maintaining the government's digital infrastructure, including this specific portal for the Ministry of Social Justice & Empowerment. The content here is purely for technical fault-finding.",
        "You would use this page only if you found a technical bug or error with the website. This includes issues like a broken link, a page not loading correctly, a database connection error, failure of the login system, or a non-functioning 'submit' button. This page is not for any questions related to your personal application, its status, your eligibility for a scheme, or policy information. The NIC team manages the website's code and servers; they do not have access to or knowledge of the specific scheme application data or its verification status.",
        "NIC Technical Support Team:",
        "For any technical issues regarding this portal (e.g., website errors, page not loading), please contact:",
        "• Shri. [Name], Senior Director (IT)",
        "• Email: hod-sje[at]nic[dot]in | Phone: 011-2XXXXXXX",
        "• Smt. [Name], Joint Director (IT)",
        "• Email: officer1-sje[at]nic[dot]in | Phone: 011-2XXXXXXX"
      ]
    },
    hi: {
      title: 'एनआईसी (राष्ट्रीय सूचना विज्ञान केंद्र)',
      content: [
        "यह पृष्ठ वेबसाइट पोर्टल के लिए तकनीकी संपर्कों को सूचीबद्ध करता है। राष्ट्रीय सूचना विज्ञान केंद्र (NIC), इलेक्ट्रॉनिक्स और सूचना प्रौद्योगिकी मंत्रालय (MeitY) के तहत काम करता है, और भारत सरकार के लिए प्राथमिक प्रौद्योगिकी भागीदार के रूप में कार्य करता है। वे सामाजिक न्याय और अधिकारिता मंत्रालय के लिए इस विशिष्ट पोर्टल सहित सरकारी डिजिटल बुनियादी ढांचे को डिजाइन, विकसित, होस्ट और बनाए रखने के लिए जिम्मेदार हैं।",
        "आपको इस पृष्ठ का उपयोग केवल तभी करना चाहिए जब आपको वेबसाइट के साथ कोई तकनीकी बग या त्रुटि मिले। इसमें टूटे हुए लिंक, पेज का ठीक से लोड न होना, डेटाबेस कनेक्शन त्रुटि, लॉगिन सिस्टम की विफलता, या काम न करने वाला 'सबमिट' बटन जैसी समस्याएं शामिल हैं। यह पृष्ठ आपके व्यक्तिगत आवेदन, उसकी स्थिति, किसी योजना के लिए आपकी पात्रता या नीति जानकारी से संबंधित किसी भी प्रश्न के लिए नहीं है।",
        "एनआईसी तकनीकी सहायता टीम:",
        "इस पोर्टल के संबंध में किसी भी तकनीकी समस्या (जैसे, वेबसाइट त्रुटियां, पेज लोड नहीं हो रहा है) के लिए, कृपया संपर्क करें:",
        "• श्री [नाम], वरिष्ठ निदेशक (IT)",
        "• ईमेल: hod-sje[at]nic[dot]in | फोन: 011-2XXXXXXX",
        "• श्रीमती [नाम], संयुक्त निदेशक (IT)",
        "• ईमेल: officer1-sje[at]nic[dot]in | फोन: 011-2XXXXXXX"
      ]
    }
  },
  '/associated/state-nodal-offices': {
    en: {
      title: 'State Nodal Offices',
      content: [
        "This section provides a crucial directory of state-level government officers who are responsible for implementing the ministry's schemes within their specific state or union territory. These Nodal Officers act as the official bridge between the central ministry in New Delhi and the various district-level officials who may be involved in the final verification and disbursal process. They oversee the entire operation of the scheme within their region.",
        "You would contact your State Nodal Officer for help with scheme-specific problems that go beyond general inquiries. This is the correct person to contact for checking the status of your application after it has been submitted, especially if it seems stuck at the 'state verification' level. They can also resolve issues with application verification, correct data mismatches, or answer complex questions about eligibility rules and documentation requirements that are specific to your state's procedures.",
        "Directory of State Nodal Officers:",
        "1. Andhra Pradesh: Dr. A. B. Koteswara Rao, Director, Social Welfare Dept. (0866-2XXXXXX | dir-sw[at]ap[dot]gov[dot]in)",
        "2. Chhattisgarh: Shri P. Dayanand, Commissioner, Social Welfare (0771-2XXXXXX | comm-sw[dot]cg[at]nic[dot]in)",
        "3. Maharashtra: Dr. Prashant Narnaware, Commissioner, Social Justice (020-2XXXXXX | comm[dot]sjsa-mah[at]gov[dot]in)",
        "4. Uttar Pradesh: Shri. Rakesh Kumar, Director, Social Welfare (0522-2XXXXXX | dir-sw[at]up[dot]gov[dot]in)",
        "(and so on for all other states and UTs)"
      ]
    },
    hi: {
      title: 'राज्य नोडल कार्यालय',
      content: [
        "यह अनुभाग राज्य स्तर के सरकारी अधिकारियों की एक महत्वपूर्ण निर्देशिका प्रदान करता है जो अपने विशिष्ट राज्य या केंद्र शासित प्रदेश में मंत्रालय की योजनाओं को लागू करने के लिए जिम्मेदार हैं। ये नोडल अधिकारी नई दिल्ली में केंद्रीय मंत्रालय और विभिन्न जिला स्तर के अधिकारियों के बीच आधिकारिक पुल के रूप में कार्य करते हैं जो अंतिम सत्यापन और संवितरण प्रक्रिया में शामिल हो सकते हैं।",
        "आपको सामान्य पूछताछ से परे योजना-विशिष्ट समस्याओं में सहायता के लिए अपने राज्य नोडल अधिकारी से संपर्क करना चाहिए। आवेदन जमा होने के बाद उसकी स्थिति की जांच करने के लिए यह सही व्यक्ति है, खासकर यदि यह 'राज्य सत्यापन' स्तर पर अटका हुआ लगता है। वे आवेदन सत्यापन, डेटा बेमेल को सही करने, या पात्रता नियमों और दस्तावेज़ीकरण आवश्यकताओं के बारे में जटिल प्रश्नों को हल कर सकते हैं।",
        "राज्य नोडल अधिकारियों की निर्देशिका:",
        "1. आंध्र प्रदेश: डॉ. ए. बी. कोटेश्वर राव, निदेशक, समाज कल्याण विभाग (0866-2XXXXXX)",
        "2. छत्तीसगढ़: श्री पी. दयानंद, आयुक्त, समाज कल्याण (0771-2XXXXXX)",
        "3. महाराष्ट्र: डॉ. प्रशांत नारनवरे, आयुक्त, सामाजिक न्याय (020-2XXXXXX)",
        "4. उत्तर प्रदेश: श्री राकेश कुमार, निदेशक, समाज कल्याण (0522-2XXXXXX)",
        "(और अन्य सभी राज्यों और केंद्र शासित प्रदेशों के लिए इसी तरह)"
      ]
    }
  },
  '/associated/help-centres': {
    en: {
      title: 'Help Centres',
      content: [
        "This page provides general helpdesk and support contacts for all users of the portal. This is the 'Level 1' or frontline support and should be the first place you look for common questions or problems. This team is trained to handle a high volume of general inquiries, guide users through the website, and troubleshoot common issues like password resets or understanding the application process.",
        "This page is used for general inquiries, password resets, and getting application support. When you contact this helpdesk via email, it often creates a 'support ticket' to track your query and ensure you get a response. This is different from the State Nodal Officer (who handles complex, state-level verifications) and the NIC team (who handles technical website bugs). The help centre is also where you find links for escalating a problem. If the regular helpdesk cannot solve your issue, the Grievance Redressal section directs you to the official platform, CPGRAMS (Centralized Public Grievance Redress and Monitoring System), where you can file a formal complaint that will be tracked by higher authorities.",
        "National Helpdesk:",
        "For any general queries related to schemes or the portal, please contact the helpdesk:",
        "• Toll-Free Helpline: 1800-XXX-XXXX",
        "• Email Support: helpdesk-sje[at]gov[dot]in",
        "• Timings: Monday - Saturday (9:00 AM to 6:00 PM)",
        "Specific Scheme Helplines:",
        "• National Scholarship Portal: 0120-6619540",
        "• Senior Citizen Helpline (Toll-Free): 14567",
        "• Nasha Mukt Bharat Abhiyan: 1800-11-0031",
        "Grievance Redressal:",
        "If your issue is not resolved, you may file a formal grievance through the Centralized Public Grievance Redress and Monitoring System (CPGRAMS) at pgportal.gov.in."
      ]
    },
    hi: {
      title: 'सहायता केंद्र',
      content: [
        "यह पृष्ठ पोर्टल के सभी उपयोगकर्ताओं के लिए सामान्य हेल्पडेस्क और सहायता संपर्क प्रदान करता है। यह 'लेवल 1' सहायता है और सामान्य प्रश्नों या समस्याओं के लिए आपको सबसे पहले यहीं देखना चाहिए। यह टीम सामान्य पूछताछ को संभालने, उपयोगकर्ताओं को वेबसाइट के माध्यम से मार्गदर्शन करने और पासवर्ड रीसेट जैसी सामान्य समस्याओं का निवारण करने के लिए प्रशिक्षित है।",
        "इस पृष्ठ का उपयोग सामान्य पूछताछ, पासवर्ड रीसेट और आवेदन सहायता प्राप्त करने के लिए किया जाता है। यह राज्य नोडल अधिकारी (जो जटिल, राज्य-स्तरीय सत्यापन संभालते हैं) और एनआईसी टीम (जो तकनीकी वेबसाइट बग संभालते हैं) से अलग है। यदि नियमित हेल्पडेस्क आपकी समस्या का समाधान नहीं कर सकता है, तो शिकायत निवारण अनुभाग आपको आधिकारिक मंच, CPGRAMS (केंद्रीकृत लोक शिकायत निवारण और निगरानी प्रणाली) पर निर्देशित करता है।",
        "राष्ट्रीय हेल्पडेस्क:",
        "योजनाओं या पोर्टल से संबंधित किसी भी सामान्य प्रश्न के लिए, कृपया हेल्पडेस्क से संपर्क करें:",
        "• टोल-फ्री हेल्पलाइन: 1800-XXX-XXXX",
        "• ईमेल सहायता: helpdesk-sje[at]gov[dot]in",
        "• समय: सोमवार - शनिवार (सुबह 9:00 बजे से शाम 6:00 बजे तक)",
        "विशिष्ट योजना हेल्पलाइन:",
        "• राष्ट्रीय छात्रवृत्ति पोर्टल: 0120-6619540",
        "• वरिष्ठ नागरिक हेल्पलाइन: 14567",
        "• नशा मुक्त भारत अभियान: 1800-11-0031",
        "शिकायत निवारण:",
        "यदि आपकी समस्या का समाधान नहीं होता है, तो आप pgportal.gov.in पर केंद्रीकृत लोक शिकायत निवारण और निगरानी प्रणाली (CPGRAMS) के माध्यम से औपचारिक शिकायत दर्ज कर सकते हैं।"
      ]
    }
  },
  // --- Schemes Content ---
  '/scheme/1': {
    en: {
      title: 'Post-Matric Scholarship for SC',
      content: [
        "The Post-Matric Scholarship for Scheduled Caste students is a Centrally Sponsored Scheme. The objective of the scheme is to appreciably increase the Gross Enrolment Ratio of SC students in higher education with a focus on those from the poorest households.",
        "Eligibility: Scholarships will be paid to the students whose parents'/guardians' income from all sources does not exceed Rs. 2,50,000/- (Rupees Two Lakh Fifty Thousand only) per annum.",
        "Scope: The scholarship includes maintenance allowance, reimbursement of compulsory non-refundable fees, study tour charges, thesis typing/printing charges for research scholars, book allowance for students pursuing correspondence courses, book bank facility for specified courses, and additional allowance for students with disabilities.",
        "How to Apply: Students should apply through the National Scholarship Portal (NSP). It is mandatory to have the bank account seeded with Aadhaar for Direct Benefit Transfer (DBT) of the scholarship amount."
      ]
    },
    hi: {
      title: 'अनुसूचित जाति के लिए पोस्ट-मैट्रिक छात्रवृत्ति',
      content: [
        "अनुसूचित जाति के छात्रों के लिए पोस्ट-मैट्रिक छात्रवृत्ति एक केंद्र प्रायोजित योजना है। योजना का उद्देश्य उच्च शिक्षा में अनुसूचित जाति के छात्रों के सकल नामांकन अनुपात में उल्लेखनीय वृद्धि करना है, जिसमें सबसे गरीब परिवारों के छात्रों पर विशेष ध्यान दिया गया है।",
        "पात्रता: उन छात्रों को छात्रवृत्ति का भुगतान किया जाएगा जिनके माता-पिता/अभिभावकों की सभी स्रोतों से आय 2,50,000/- रुपये (दो लाख पचास हजार रुपये मात्र) प्रति वर्ष से अधिक नहीं है।",
        "दायरा: छात्रवृत्ति में रखरखाव भत्ता, अनिवार्य गैर-वापसी योग्य शुल्क की प्रतिपूर्ति, अध्ययन दौरा शुल्क, शोधार्थियों के लिए थीसिस टाइपिंग/प्रिंटिंग शुल्क, पत्राचार पाठ्यक्रमों का पीछा करने वाले छात्रों के लिए पुस्तक भत्ता, और विकलांग छात्रों के लिए अतिरिक्त भत्ता शामिल है।",
        "आवेदन कैसे करें: छात्रों को राष्ट्रीय छात्रवृत्ति पोर्टल (NSP) के माध्यम से आवेदन करना चाहिए। छात्रवृत्ति राशि के प्रत्यक्ष लाभ हस्तांतरण (DBT) के लिए बैंक खाते का आधार से जुड़ा होना अनिवार्य है।"
      ]
    }
  },
  '/scheme/2': {
    en: {
      title: 'Pre-Matric Scholarship for SC',
      content: [
        "The Pre-Matric Scholarship Scheme for Scheduled Castes & Others is aimed at reducing the dropout rate and promoting the education of SC children in classes IX and X.",
        "Objective: To support parents of SC children for education of their wards studying in classes IX and X so that the incidence of drop-out, especially in the transition from the elementary to the secondary stage is minimized.",
        "Benefits: The scheme provides a monthly academic allowance and an annual ad-hoc grant to cover incidental expenses.",
        "Eligibility: Student should belong to Scheduled Caste. Parent/Guardian's income should not exceed Rs. 2.50 Lakh per annum. The student should not be getting any other Centrally-funded Pre-Matric Scholarship."
      ]
    },
    hi: {
      title: 'अनुसूचित जाति के लिए प्री-मैट्रिक छात्रवृत्ति',
      content: [
        "अनुसूचित जाति और अन्य के लिए प्री-मैट्रिक छात्रवृत्ति योजना का उद्देश्य ड्रॉपआउट दर को कम करना और कक्षा IX और X में अनुसूचित जाति के बच्चों की शिक्षा को बढ़ावा देना है।",
        "उद्देश्य: अनुसूचित जाति के बच्चों के माता-पिता को उनके बच्चों की शिक्षा के लिए सहायता प्रदान करना जो कक्षा IX और X में पढ़ रहे हैं ताकि ड्रॉप-आउट की घटनाओं को कम किया जा सके।",
        "लाभ: योजना आकस्मिक खर्चों को कवर करने के लिए एक मासिक शैक्षणिक भत्ता और एक वार्षिक तदर्थ अनुदान प्रदान करती है।",
        "पात्रता: छात्र अनुसूचित जाति का होना चाहिए। माता-पिता/अभिभावक की आय 2.50 लाख रुपये प्रति वर्ष से अधिक नहीं होनी चाहिए।"
      ]
    }
  },
  '/scheme/3': {
    en: {
      title: 'National Overseas Scholarship',
      content: [
        "The National Overseas Scholarship (NOS) is a Central Sector Scheme to facilitate the low-income students belonging to the Scheduled Castes, Denotified Nomadic and Semi-Nomadic Tribes, Landless Agricultural Labourers and Traditional Artisans category to obtain higher education via Master degree or Ph.D. courses by studying abroad.",
        "Financial Assistance: The scheme covers tuition fees, maintenance allowance, contingency allowance, visa fees, equipment allowance, poll tax, medical insurance premium, and air passage.",
        "Selection: 125 slots are available annually. Selection is based on the unconditional offer of admission from a ranked foreign university.",
        "Income Ceiling: Total family income from all sources shall not exceed Rs. 8.00 lakh per annum."
      ]
    },
    hi: {
      title: 'राष्ट्रीय प्रवासी छात्रवृत्ति',
      content: [
        "राष्ट्रीय प्रवासी छात्रवृत्ति (NOS) अनुसूचित जातियों, विमुक्त घुमंतू और अर्ध-घुमंतू जनजातियों, भूमिहीन खेतिहर मजदूरों और पारंपरिक कारीगरों की श्रेणी के कम आय वाले छात्रों को विदेश में अध्ययन करके मास्टर डिग्री या पीएचडी पाठ्यक्रम के माध्यम से उच्च शिक्षा प्राप्त करने की सुविधा प्रदान करने के लिए एक केंद्रीय क्षेत्र की योजना है।",
        "वित्तीय सहायता: योजना में शिक्षण शुल्क, रखरखाव भत्ता, आकस्मिकता भत्ता, वीजा शुल्क, उपकरण भत्ता, और हवाई यात्रा शामिल है।",
        "चयन: प्रतिवर्ष 125 स्लॉट उपलब्ध हैं। चयन रैंक वाले विदेशी विश्वविद्यालय से प्रवेश के बिना शर्त प्रस्ताव पर आधारित है।",
        "आय सीमा: सभी स्रोतों से कुल पारिवारिक आय 8.00 लाख रुपये प्रति वर्ष से अधिक नहीं होनी चाहिए।"
      ]
    }
  },
  '/scheme/4': {
    en: {
      title: 'SMILE: Support for Marginalized Individuals',
      content: [
        "SMILE (Support for Marginalized Individuals for Livelihood and Enterprise) is a comprehensive umbrella scheme for the welfare of Transgender persons and persons engaged in the act of begging.",
        "Sub-scheme for Transgender Persons: Provides scholarships for students, skill development under PM-DAKSH, composite medical health packages, and shelter homes ('Garima Greh').",
        "Sub-scheme for Persons engaged in Begging: Focuses on survey and identification, mobilization, rescue/shelter home and comprehensive rehabilitation through medical care, education, and skill development.",
        "Goal: To provide social security and necessary support to bring these marginalized groups into the mainstream society."
      ]
    },
    hi: {
      title: 'स्माइल (SMILE): सीमांत व्यक्तियों के लिए सहायता',
      content: [
        "स्माइल (आजीविका और उद्यम के लिए सीमांत व्यक्तियों के लिए सहायता) ट्रांसजेंडर व्यक्तियों और भीख मांगने के कार्य में लगे व्यक्तियों के कल्याण के लिए एक व्यापक योजना है।",
        "ट्रांसजेंडर व्यक्तियों के लिए उप-योजना: छात्रों के लिए छात्रवृत्ति, PM-DAKSH के तहत कौशल विकास, चिकित्सा स्वास्थ्य पैकेज और आश्रय गृह ('गरिमा गृह') प्रदान करता है।",
        "भीख मांगने में लगे व्यक्तियों के लिए उप-योजना: सर्वेक्षण और पहचान, लामबंदी, बचाव/आश्रय गृह और चिकित्सा देखभाल, शिक्षा और कौशल विकास के माध्यम से व्यापक पुनर्वास पर केंद्रित है।",
        "लक्ष्य: इन सीमांत समूहों को मुख्यधारा के समाज में लाने के लिए सामाजिक सुरक्षा और आवश्यक सहायता प्रदान करना।"
      ]
    }
  },
  '/scheme/5': {
    en: {
      title: 'National Portal for Transgender Persons',
      content: [
        "This portal allows Transgender persons to apply online for a Certificate of Identity and Identity Card without physical interface.",
        "Key Features: Applicants can track the status of their application. The certificate is issued by the District Magistrate.",
        "Benefits: The Identity Card is a critical document for accessing various welfare schemes of the government, including scholarships and medical benefits under the SMILE scheme.",
        "Process: Register on the portal, fill out the application form, upload a photograph and affidavit. Once approved, download the ID card digitally."
      ]
    },
    hi: {
      title: 'ट्रांसजेंडर व्यक्तियों के लिए राष्ट्रीय पोर्टल',
      content: [
        "यह पोर्टल ट्रांसजेंडर व्यक्तियों को भौतिक इंटरफ़ेस के बिना पहचान प्रमाण पत्र और पहचान पत्र के लिए ऑनलाइन आवेदन करने की अनुमति देता है।",
        "मुख्य विशेषताएं: आवेदक अपने आवेदन की स्थिति को ट्रैक कर सकते हैं। प्रमाण पत्र जिला मजिस्ट्रेट द्वारा जारी किया जाता है।",
        "लाभ: पहचान पत्र सरकार की विभिन्न कल्याणकारी योजनाओं, जिसमें स्माइल योजना के तहत छात्रवृत्ति और चिकित्सा लाभ शामिल हैं, तक पहुंचने के लिए एक महत्वपूर्ण दस्तावेज है।",
        "प्रक्रिया: पोर्टल पर पंजीकरण करें, आवेदन पत्र भरें, एक तस्वीर और हलफनामा अपलोड करें। स्वीकृत होने के बाद, आईडी कार्ड को डिजिटल रूप से डाउनलोड करें।"
      ]
    }
  },
  '/scheme/6': {
    en: {
      title: 'Senior Citizens Welfare',
      content: [
        "The Ministry implements the Atal Vayo Abhyuday Yojana (AVYAY) for the welfare of Senior Citizens.",
        "Components: It includes the Integrated Programme for Senior Citizens (IPSrC) which funds NGOs for running Old Age Homes, and the Rashtriya Vayoshri Yojana (RVY) which provides physical aids and assisted-living devices to BPL senior citizens.",
        "Elderline: A National Helpline for Senior Citizens (14567) has been established to provide information, guidance, and emotional support.",
        "Objective: To improve the quality of life of the Senior Citizens by providing basic amenities like shelter, food, medical care and entertainment opportunities."
      ]
    },
    hi: {
      title: 'वरिष्ठ नागरिक कल्याण',
      content: [
        "मंत्रालय वरिष्ठ नागरिकों के कल्याण के लिए अटल वयो अभ्युदय योजना (AVYAY) लागू करता है।",
        "घटक: इसमें वरिष्ठ नागरिकों के लिए एकीकृत कार्यक्रम (IPSrC) शामिल है जो वृद्धाश्रम चलाने के लिए गैर सरकारी संगठनों को वित्तपोषित करता है, और राष्ट्रीय वयोश्री योजना (RVY) जो BPL वरिष्ठ नागरिकों को शारीरिक सहायता और जीवन सहायक उपकरण प्रदान करती है।",
        "एल्डरलाइन: जानकारी, मार्गदर्शन और भावनात्मक समर्थन प्रदान करने के लिए वरिष्ठ नागरिकों (14567) के लिए एक राष्ट्रीय हेल्पलाइन स्थापित की गई है।",
        "उद्देश्य: आश्रय, भोजन, चिकित्सा देखभाल और मनोरंजन के अवसर जैसी बुनियादी सुविधाएं प्रदान करके वरिष्ठ नागरिकों के जीवन की गुणवत्ता में सुधार करना।"
      ]
    }
  },
  // --- News Content ---
  '/news/1': {
    en: {
      title: 'Applications open for Post-Matric Scholarship 2025-26',
      content: [
        "The Ministry of Social Justice & Empowerment is pleased to announce that the National Scholarship Portal (NSP) is now accepting applications for the Post-Matric Scholarship for SC students for the academic year 2025-26.",
        "Important Dates: The portal opened on 12th December 2025. The last date for student registration is 31st January 2026. Defective application verification must be completed by 15th February 2026.",
        "Advisory: Students are strictly advised to ensure their bank accounts are Aadhaar-seeded. Accounts that are not DBT-enabled will result in transaction failures.",
        "Documents Required: Income certificate, Caste certificate, Mark sheet of last qualifying exam, and a valid mobile number linked to Aadhaar."
      ]
    },
    hi: {
      title: 'पोस्ट-मैट्रिक छात्रवृत्ति 2025-26 के लिए आवेदन खुले',
      content: [
        "सामाजिक न्याय और अधिकारिता मंत्रालय को यह घोषणा करते हुए खुशी हो रही है कि राष्ट्रीय छात्रवृत्ति पोर्टल (NSP) अब शैक्षणिक वर्ष 2025-26 के लिए अनुसूचित जाति के छात्रों के लिए पोस्ट-मैट्रिक छात्रवृत्ति के लिए आवेदन स्वीकार कर रहा है।",
        "महत्वपूर्ण तिथियां: पोर्टल 12 दिसंबर 2025 को खुला। छात्र पंजीकरण की अंतिम तिथि 31 जनवरी 2026 है।",
        "सलाह: छात्रों को सख्ती से सलाह दी जाती है कि वे सुनिश्चित करें कि उनके बैंक खाते आधार से जुड़े हैं।",
        "आवश्यक दस्तावेज: आय प्रमाण पत्र, जाति प्रमाण पत्र, अंतिम योग्यता परीक्षा की अंक तालिका, और आधार से जुड़ा एक वैध मोबाइल नंबर।"
      ]
    }
  },
  '/news/2': {
    en: {
      title: 'New DBT guidelines released for associated banks',
      content: [
        "The Department has issued a new circular regarding the processing of scholarship payments via the Direct Benefit Transfer (DBT) mode.",
        "NPCI Mapping: All banks have been instructed to prioritize the mapping of beneficiary bank accounts with the NPCI mapper to avoid failures due to 'Aadhaar not mapped to account number'.",
        "Inactive Accounts: Beneficiaries are requested to keep their bank accounts active by performing at least one transaction every 3 months.",
        "These guidelines come into effect immediately to ensure timely disbursal of funds for the 2025-26 fiscal cycle."
      ]
    },
    hi: {
      title: 'संबद्ध बैंकों के लिए नई डीबीटी दिशानिर्देश जारी',
      content: [
        "विभाग ने प्रत्यक्ष लाभ हस्तांतरण (DBT) मोड के माध्यम से छात्रवृत्ति भुगतान के प्रसंस्करण के संबंध में एक नया परिपत्र जारी किया है।",
        "NPCI मैपिंग: सभी बैंकों को निर्देश दिया गया है कि वे 'आधार खाता संख्या से मैप नहीं' होने के कारण विफलताओं से बचने के लिए NPCI मैपर के साथ लाभार्थी बैंक खातों की मैपिंग को प्राथमिकता दें।",
        "निष्क्रिय खाते: लाभार्थियों से अनुरोध है कि वे हर 3 महीने में कम से कम एक लेनदेन करके अपने बैंक खातों को सक्रिय रखें।",
        "ये दिशानिर्देश 2025-26 के वित्तीय चक्र के लिए धन के समय पर वितरण को सुनिश्चित करने के लिए तत्काल प्रभाव से लागू होते हैं।"
      ]
    }
  },
  '/news/3': {
    en: {
      title: 'Awareness camp scheduled in Varanasi regarding PM-AJAY',
      content: [
        "A mega awareness camp is being organized in Varanasi to disseminate information about the Pradhan Mantri Anusuchit Jaati Abhyuday Yojana (PM-AJAY).",
        "Venue & Date: The event will be held at the Town Hall Grounds on 20th December 2025, starting at 10:00 AM.",
        "Activities: On-spot registration for the Adarsh Gram component, distribution of skill development kits, and grievance redressal counters for pending applications.",
        "All local residents and stakeholders are invited to attend."
      ]
    },
    hi: {
      title: 'पीएम-अजय के संबंध में वाराणसी में जागरूकता शिविर निर्धारित',
      content: [
        "प्रधानमंत्री अनुसूचित जाति अभ्युदय योजना (PM-AJAY) के बारे में जानकारी प्रसारित करने के लिए वाराणसी में एक मेगा जागरूकता शिविर का आयोजन किया जा रहा है।",
        "स्थान और तिथि: कार्यक्रम 20 दिसंबर 2025 को टाउन हॉल मैदान में सुबह 10:00 बजे से आयोजित किया जाएगा।",
        "गतिविधियां: आदर्श ग्राम घटक के लिए ऑन-स्पॉट पंजीकरण, कौशल विकास किट का वितरण।",
        "सभी स्थानीय निवासियों को इसमें शामिल होने के लिए आमंत्रित किया जाता है।"
      ]
    }
  },
  '/news/4': {
    en: {
      title: 'Last date extended for National Overseas Scholarship',
      content: [
        "In view of the heavy traffic on the portal and requests from student associations, the Ministry has decided to extend the last date for submission of applications for the National Overseas Scholarship (NOS).",
        "New Deadline: The new deadline for submission is 15th January 2026.",
        "Correction Window: A correction window will be open from 16th January to 20th January 2026 for students to rectifiy any errors in their uploaded documents.",
        "No further extension will be granted."
      ]
    },
    hi: {
      title: 'राष्ट्रीय प्रवासी छात्रवृत्ति के लिए अंतिम तिथि बढ़ाई गई',
      content: [
        "पोर्टल पर भारी ट्रैफिक और छात्र संघों के अनुरोधों को देखते हुए, मंत्रालय ने राष्ट्रीय प्रवासी छात्रवृत्ति (NOS) के लिए आवेदन जमा करने की अंतिम तिथि बढ़ाने का निर्णय लिया है।",
        "नई समय सीमा: जमा करने की नई समय सीमा 15 जनवरी 2026 है।",
        "सुधार विंडो: छात्रों के लिए अपने अपलोड किए गए दस्तावेजों में किसी भी त्रुटि को सुधारने के लिए 16 जनवरी से 20 जनवरी 2026 तक एक सुधार विंडो खुली रहेगी।"
      ]
    }
  },
  '/news/5': {
    en: {
      title: 'SMILE scheme beneficiaries reach new milestone',
      content: [
        "The SMILE scheme (Support for Marginalized Individuals for Livelihood and Enterprise) has successfully rehabilitated over 5,000 individuals engaged in the act of begging across 10 pilot cities.",
        "Achievement: The Ministry celebrated this milestone today. Beneficiaries have been linked to skill development centers and provided with identity cards.",
        "Expansion: Based on this success, the scheme is now being expanded to 30 more cities in the next phase starting January 2026.",
        "The Minister praised the efforts of the implementing agencies and NGOs working on the ground."
      ]
    },
    hi: {
      title: 'स्माइल योजना के लाभार्थियों ने नया मील का पत्थर हासिल किया',
      content: [
        "स्माइल योजना ने 10 पायलट शहरों में भीख मांगने के कार्य में लगे 5,000 से अधिक व्यक्तियों का सफलतापूर्वक पुनर्वास किया है।",
        "उपलब्धि: मंत्रालय ने आज इस मील के पत्थर का जश्न मनाया। लाभार्थियों को कौशल विकास केंद्रों से जोड़ा गया है और पहचान पत्र प्रदान किए गए हैं।",
        "विस्तार: इस सफलता के आधार पर, अब जनवरी 2026 से शुरू होने वाले अगले चरण में योजना का विस्तार 30 और शहरों में किया जा रहा है।"
      ]
    }
  }
};

// Fallback logic for UI Elements text
const DEFAULT_EN = {
  ministryName: 'Department of Social Justice & Empowerment',
  ministryParent: 'Ministry of Social Justice & Empowerment',
  govt: 'Government of India',
  searchPlaceholder: 'Search...',
  login: 'Login',
  newsTitle: 'News / Events (What\'s New)',
  schemesTitle: 'Major Schemes',
  viewAll: 'View All',
  footerContent: 'Content owned by Department of Social Justice and Empowerment. Designed, Developed, and Hosted by National Informatics Centre (NIC).',
};

// Translations for static UI elements
export const DICTIONARY: Record<string, Record<string, string>> = {
  en: DEFAULT_EN,
  hi: {
    ministryName: 'सामाजिक न्याय और अधिकारिता विभाग',
    ministryParent: 'सामाजिक न्याय और अधिकारिता मंत्रालय',
    govt: 'भारत सरकार',
    searchPlaceholder: 'खोजें...',
    login: 'लॉग इन करें',
    newsTitle: 'समाचार / कार्यक्रम (नया क्या है)',
    schemesTitle: 'प्रमुख योजनाएं',
    viewAll: 'सभी देखें',
    footerContent: 'सामग्री का स्वामित्व सामाजिक न्याय और अधिकारिता विभाग के पास है। राष्ट्रीय सूचना विज्ञान केंद्र (एनआईसी) द्वारा डिज़ाइन, विकसित और होस्ट किया गया।',
  },
  // Basic fallbacks for other languages to prevent crashes.
  // In a real app, these would be fully populated.
  as: { ...DEFAULT_EN, ministryName: 'সামাজিক ন্যায় আৰু সৱলীকৰণ বিভাগ', govt: 'ভাৰত চৰকাৰ' },
  bn: {
    ...DEFAULT_EN,
    ministryName: 'সামাজিক ন্যায় ও ক্ষমতায়ন বিভাগ',
    ministryParent: 'সামাজিক ন্যায় ও ক্ষমতায়ন মন্ত্রক',
    govt: 'ভারত সরকার',
    searchPlaceholder: 'অনুসন্ধান...',
    login: 'লগ ইন',
    newsTitle: 'খবর / ইভেন্ট (নতুন কি)',
    schemesTitle: 'প্রধান প্রকল্পসমূহ',
    viewAll: 'সব দেখুন'
  },
  gu: {
    ...DEFAULT_EN,
    ministryName: 'સામાજિક ન્યાય અને અધિકારિતા વિભાગ',
    ministryParent: 'સામાજિક ન્યાય અને અધિકારિતા મંત્રાલય',
    govt: 'ભારત સરકાર',
    searchPlaceholder: 'શોધ...',
    login: 'લૉગિન',
    newsTitle: 'સમાચાર / ઇવેન્ટ્સ',
    schemesTitle: 'મુખ્ય યોજનાઓ',
    viewAll: 'બધું જુઓ'
  },
  kn: {
    ...DEFAULT_EN,
    ministryName: 'ಸಾಮಾಜಿಕ ನ್ಯಾಯ ಮತ್ತು ಸಬಲೀಕರಣ ಇಲಾಖೆ',
    ministryParent: 'ಸಾಮಾಜಿಕ ನ್ಯಾಯ ಮತ್ತು ಸಬಲೀಕರಣ ಸಚಿವಾಲಯ',
    govt: 'ಭಾರತ ಸರ್ಕಾರ',
    searchPlaceholder: 'ಹುಡುಕಿ...',
    login: 'ಲಾಗಿನ್',
    newsTitle: 'ಸುದ್ದಿ / ಘಟನೆಗಳು',
    schemesTitle: 'ಪ್ರಮುಖ ಯೋಜನೆಗಳು',
    viewAll: 'ಎಲ್ಲವನ್ನೂ ನೋಡಿ'
  },
  ks: { ...DEFAULT_EN, ministryName: 'محکمہ سماجی انصاف اور بااختیار بنانا' }, 
  kok: { ...DEFAULT_EN, ministryName: 'सामाजीक न्याय आनी सक्षमीकरण विभाग' },
  ml: {
    ...DEFAULT_EN,
    ministryName: 'സാമൂഹ്യനീതി ശാക്തീകരണ വകുപ്പ്',
    ministryParent: 'സാമൂഹ്യനീതി ശാക്തീകരണ മന്ത്രാലയം',
    govt: 'ഇന്ത്യൻ സർക്കാർ',
    searchPlaceholder: 'തിരയുക...',
    login: 'ലോഗിൻ',
    newsTitle: 'വാർത്തകൾ / ഇവന്റുകൾ',
    schemesTitle: 'പ്രധാന പദ്ധതികൾ',
    viewAll: 'എല്ലാം കാണുക'
  },
  mr: {
    ...DEFAULT_EN,
    ministryName: 'सामाजिक न्याय व सक्षमीकरण विभाग',
    ministryParent: 'सामाजिक न्याय व सक्षमीकरण मंत्रालय',
    govt: 'भारत सरकार',
    searchPlaceholder: 'शोधा...',
    login: 'लॉगिन',
    newsTitle: 'बातम्या / कार्यक्रम',
    schemesTitle: 'प्रमुख योजना',
    viewAll: 'सर्व पहा'
  },
  ne: { ...DEFAULT_EN, ministryName: 'सामाजिक न्याय र अधिकारिता विभाग' },
  or: {
    ...DEFAULT_EN,
    ministryName: 'ସାମାଜିକ ନ୍ୟାୟ ଏବଂ ସଶକ୍ତିକରଣ ବିଭାଗ',
    govt: 'ଭାରତ ସରକାର',
    searchPlaceholder: 'ସନ୍ଧାନ...',
    newsTitle: 'ଖବର / ଘଟଣା',
    schemesTitle: 'ମୁଖ୍ୟ ଯୋଜନା',
    viewAll: 'ସମସ୍ତ ଦେଖନ୍ତୁ'
  },
  pa: {
    ...DEFAULT_EN,
    ministryName: 'ਸਮਾਜਿਕ ਨਿਆਂ ਅਤੇ ਅਧਿਕਾਰਤਾ ਵਿਭਾਗ',
    ministryParent: 'ਸਮਾਜਿਕ ਨਿਆਂ ਅਤੇ ਅਧਿਕਾਰਤਾ ਮੰਤਰਾਲੇ',
    govt: 'ਭਾਰਤ ਸਰਕਾਰ',
    searchPlaceholder: 'ਖੋਜ...',
    login: 'ਲਾਗਿਨ',
    newsTitle: 'ਖ਼ਬਰਾਂ / ਸਮਾਗਮ',
    schemesTitle: 'ਮੁੱਖ ਸਕੀਮਾਂ',
    viewAll: 'ਸਭ ਦੇਖੋ'
  },
  sa: { ...DEFAULT_EN, ministryName: 'सामाजिकन्याय-सशक्तीकरणविभागः', govt: 'भारतसर्वकारः' },
  sd: { ...DEFAULT_EN, ministryName: 'سماجي انصاف ۽ بااختيار بڻائڻ وارو کاتو' },
  ta: {
    ...DEFAULT_EN,
    ministryName: 'சமூக நீதி மற்றும் அதிகாரமளித்தல் துறை',
    ministryParent: 'சமூக நீதி மற்றும் அதிகாரமளித்தல் அமைச்சகம்',
    govt: 'இந்திய அரசு',
    searchPlaceholder: 'தேடு...',
    login: 'உள்நுழைக',
    newsTitle: 'செய்திகள் / நிகழ்வுகள்',
    schemesTitle: 'முக்கிய திட்டங்கள்',
    viewAll: 'அனைத்தையும் காண்க'
  },
  te: {
    ...DEFAULT_EN,
    ministryName: 'సామాజిక న్యాయం మరియు సాధికారత శాఖ',
    ministryParent: 'సామాజిక న్యాయం మరియు సాధికారత మంత్రిత్వ శాఖ',
    govt: 'భారత ప్రభుత్వం',
    searchPlaceholder: 'శోధించండి...',
    login: 'లాగిన్',
    newsTitle: 'వార్తలు / ఈవెంట్‌లు',
    schemesTitle: 'ప్రధాన పథకాలు',
    viewAll: 'అన్నీ వీక్షించండి'
  },
  ur: { ...DEFAULT_EN, ministryName: 'محکمہ سماجی انصاف اور تفویض اختیارات', govt: 'حکومت ہند', login: 'لاگ ان' },
  mai: { ...DEFAULT_EN, ministryName: 'सामाजिक न्याय आर अधिकारिता विभाग' },
  doi: { ...DEFAULT_EN },
  brx: { ...DEFAULT_EN },
  sat: { ...DEFAULT_EN }
};

// Translations for the main Navigation Bar Items
export const NAV_TRANSLATIONS: Record<string, Record<string, string>> = {
  'Home': { hi: 'मुखपृष्ठ', bn: 'হোম', mr: 'मुख्यपृष्ठ', ta: 'முகப்பு', te: 'హోమ్', kn: 'ಮುಖಪುಟ', ml: 'ഹോം', gu: 'ઘર' },
  'About Us': { hi: 'हमारे बारे में', bn: 'আমাদের সম্পর্কে', mr: 'आमच्याबद्दल', ta: 'எங்களைப் பற்றி', te: 'మా గురించి', kn: 'ನಮ್ಮ ಬಗ್ಗೆ', ml: 'ഞങ്ങളെക്കുറിച്ച്', gu: 'અમારા વિશે' },
  'Associated Organisations': { hi: 'संबद्ध संगठन', bn: 'সংশ্লিষ্ট সংস্থা', mr: 'संलग्न संस्था', ta: 'தொடர்புடைய நிறுவனங்கள்', te: 'అనుబంధ సంస్థలు', kn: 'ಸಂಯೋಜಿತ ಸಂಸ್ಥೆಗಳು', ml: 'ബന്ധപ്പെട്ട സ്ഥാപനങ്ങൾ', gu: 'સંલગ્ન સંસ્થાઓ' },
  'Events': { hi: 'कार्यक्रम', bn: 'ইভেন্ট', mr: 'कार्यक्रम', ta: 'நிகழ்வுகள்', te: 'ఈవెంట్‌లు', kn: 'ಕಾರ್ಯಕ್ರಮಗಳು', ml: 'ഇവന്റുകൾ', gu: 'ઇવેન્ટ્સ' },
};
