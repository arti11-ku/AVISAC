import { useLanguage } from "@/contexts/LanguageContext";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { CheckCircle2 } from "lucide-react";
import comparisonImage from "@assets/generated_images/Account_types_comparison_illustration_9250ab82.png";

export default function Compare() {
  const { t } = useLanguage();

  const comparisonData = [
    {
      label: t("compare.purpose.label"),
      aadhaar: t("compare.purpose.aadhaar"),
      dbt: t("compare.purpose.dbt"),
    },
    {
      label: t("compare.benefits.label"),
      aadhaar: t("compare.benefits.aadhaar"),
      dbt: t("compare.benefits.dbt"),
    },
    {
      label: t("compare.requirement.label"),
      aadhaar: t("compare.requirement.aadhaar"),
      dbt: t("compare.requirement.dbt"),
    },
    {
      label: t("compare.process.label"),
      aadhaar: t("compare.process.aadhaar"),
      dbt: t("compare.process.dbt"),
    },
  ];

  return (
    <div className="min-h-screen py-8 sm:py-12 bg-background">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h1 className="text-3xl sm:text-4xl md:text-5xl font-bold text-foreground mb-4">
            {t("compare.title")}
          </h1>
          <p className="text-lg text-muted-foreground">
            {t("compare.subtitle")}
          </p>
        </div>

        <div className="mb-12 flex justify-center">
          <img 
            src={comparisonImage} 
            alt="Account Types Comparison" 
            className="max-w-full h-auto rounded-lg shadow-md"
          />
        </div>

        <div className="hidden md:block">
          <Card>
            <CardHeader>
              <div className="grid grid-cols-3 gap-4">
                <div className="text-center">
                  <CardTitle className="text-lg text-muted-foreground">Feature</CardTitle>
                </div>
                <div className="text-center">
                  <Badge className="bg-primary text-primary-foreground px-6 py-2 text-base">
                    {t("compare.aadhaar")}
                  </Badge>
                </div>
                <div className="text-center">
                  <Badge className="bg-secondary text-secondary-foreground px-6 py-2 text-base">
                    {t("compare.dbt")}
                  </Badge>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {comparisonData.map((row, index) => (
                  <div 
                    key={index} 
                    className={`grid grid-cols-3 gap-4 p-4 rounded-md ${
                      index % 2 === 0 ? "bg-muted/30" : "bg-card"
                    }`}
                    data-testid={`comparison-row-${index}`}
                  >
                    <div className="font-semibold text-foreground flex items-center">
                      {row.label}
                    </div>
                    <div className="text-sm text-muted-foreground flex items-center gap-2">
                      <CheckCircle2 className="h-4 w-4 text-primary flex-shrink-0" />
                      <span>{row.aadhaar}</span>
                    </div>
                    <div className="text-sm text-muted-foreground flex items-center gap-2">
                      <CheckCircle2 className="h-4 w-4 text-secondary flex-shrink-0" />
                      <span>{row.dbt}</span>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="md:hidden space-y-6">
          {comparisonData.map((row, index) => (
            <Card key={index} data-testid={`comparison-card-mobile-${index}`}>
              <CardHeader>
                <CardTitle className="text-lg">{row.label}</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Badge className="bg-primary text-primary-foreground mb-2">
                    {t("compare.aadhaar")}
                  </Badge>
                  <p className="text-sm text-muted-foreground">{row.aadhaar}</p>
                </div>
                <div>
                  <Badge className="bg-secondary text-secondary-foreground mb-2">
                    {t("compare.dbt")}
                  </Badge>
                  <p className="text-sm text-muted-foreground">{row.dbt}</p>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="mt-12 grid grid-cols-1 md:grid-cols-2 gap-6">
          <Card className="border-primary/30">
            <CardHeader>
              <CardTitle className="text-primary">
                {t("compare.aadhaar")}
              </CardTitle>
              <CardDescription>Foundation for digital identity</CardDescription>
            </CardHeader>
            <CardContent>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li className="flex items-start gap-2">
                  <CheckCircle2 className="h-5 w-5 text-primary flex-shrink-0 mt-0.5" />
                  <span>Essential for KYC compliance across all financial services</span>
                </li>
                <li className="flex items-start gap-2">
                  <CheckCircle2 className="h-5 w-5 text-primary flex-shrink-0 mt-0.5" />
                  <span>Enables paperless, presence-less authentication</span>
                </li>
                <li className="flex items-start gap-2">
                  <CheckCircle2 className="h-5 w-5 text-primary flex-shrink-0 mt-0.5" />
                  <span>Required for opening new bank accounts</span>
                </li>
                <li className="flex items-start gap-2">
                  <CheckCircle2 className="h-5 w-5 text-primary flex-shrink-0 mt-0.5" />
                  <span>Simplifies identity verification processes</span>
                </li>
              </ul>
            </CardContent>
          </Card>

          <Card className="border-secondary/30">
            <CardHeader>
              <CardTitle className="text-secondary">
                {t("compare.dbt")}
              </CardTitle>
              <CardDescription>Direct government benefit delivery</CardDescription>
            </CardHeader>
            <CardContent>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li className="flex items-start gap-2">
                  <CheckCircle2 className="h-5 w-5 text-secondary flex-shrink-0 mt-0.5" />
                  <span>Receive LPG subsidies, scholarships, and pensions directly</span>
                </li>
                <li className="flex items-start gap-2">
                  <CheckCircle2 className="h-5 w-5 text-secondary flex-shrink-0 mt-0.5" />
                  <span>Eliminates leakages and corruption in benefit distribution</span>
                </li>
                <li className="flex items-start gap-2">
                  <CheckCircle2 className="h-5 w-5 text-secondary flex-shrink-0 mt-0.5" />
                  <span>Real-time tracking of benefit payments</span>
                </li>
                <li className="flex items-start gap-2">
                  <CheckCircle2 className="h-5 w-5 text-secondary flex-shrink-0 mt-0.5" />
                  <span>Faster delivery with reduced administrative overhead</span>
                </li>
              </ul>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
