import { useLanguage } from "@/contexts/LanguageContext";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { BookOpen, Link as LinkIcon, Building2, Users } from "lucide-react";
import citizensImage from "@assets/generated_images/Citizens_using_digital_banking_63296093.png";

export default function Learn() {
  const { t } = useLanguage();

  return (
    <div className="min-h-screen py-8 sm:py-12 bg-background">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 max-w-6xl">
        <div className="text-center mb-12">
          <BookOpen className="h-16 w-16 text-primary mx-auto mb-4" />
          <h1 className="text-3xl sm:text-4xl md:text-5xl font-bold text-foreground mb-4">
            {t("nav.learn")}
          </h1>
          <p className="text-lg text-muted-foreground">
            Comprehensive guide to Aadhaar and DBT banking systems
          </p>
        </div>

        <Tabs defaultValue="aadhaar" className="w-full">
          <TabsList className="grid w-full grid-cols-2 mb-8">
            <TabsTrigger value="aadhaar" data-testid="tab-aadhaar">
              Aadhaar-Linked Accounts
            </TabsTrigger>
            <TabsTrigger value="dbt" data-testid="tab-dbt">
              DBT-Enabled Accounts
            </TabsTrigger>
          </TabsList>

          <TabsContent value="aadhaar">
            <div className="space-y-8">
              <Card>
                <CardHeader>
                  <div className="mb-2">
                    <Badge className="bg-primary text-primary-foreground">
                      Foundation of Digital Banking
                    </Badge>
                  </div>
                  <CardTitle className="text-2xl">What is Aadhaar Linking?</CardTitle>
                  <CardDescription className="text-base">
                    Understanding the basics of linking your Aadhaar to your bank account
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4 text-muted-foreground">
                  <p>
                    Aadhaar-bank account linking is the process of associating your 12-digit Aadhaar number with your bank account. 
                    This linkage serves as a robust identity verification mechanism and is mandatory for various financial services.
                  </p>
                  <p>
                    The Reserve Bank of India (RBI) and the Government of India have made Aadhaar linking essential for 
                    Know Your Customer (KYC) compliance, making banking transactions more secure and preventing fraud.
                  </p>
                </CardContent>
              </Card>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <Card>
                  <CardHeader>
                    <LinkIcon className="h-8 w-8 text-primary mb-2" />
                    <CardTitle className="text-xl">Why Link Aadhaar?</CardTitle>
                  </CardHeader>
                  <CardContent className="text-sm text-muted-foreground space-y-2">
                    <p>• <strong>Mandatory Requirement:</strong> Required by law for all bank account holders</p>
                    <p>• <strong>Simplified KYC:</strong> No need for multiple identity documents</p>
                    <p>• <strong>Paperless Process:</strong> Digital verification without physical documents</p>
                    <p>• <strong>Enhanced Security:</strong> Biometric authentication prevents unauthorized access</p>
                    <p>• <strong>Unified Identity:</strong> Single source of truth for identity verification</p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <Building2 className="h-8 w-8 text-primary mb-2" />
                    <CardTitle className="text-xl">How to Link</CardTitle>
                  </CardHeader>
                  <CardContent className="text-sm text-muted-foreground space-y-2">
                    <p><strong>Method 1 - Bank Branch:</strong> Visit with Aadhaar card, fill form, submit</p>
                    <p><strong>Method 2 - Online Banking:</strong> Log in, navigate to profile, enter Aadhaar number</p>
                    <p><strong>Method 3 - Mobile Banking:</strong> Use app, go to settings, link Aadhaar</p>
                    <p><strong>Method 4 - ATM:</strong> Use ATM, select Aadhaar services, follow prompts</p>
                    <p><strong>Verification:</strong> OTP sent to registered mobile for confirmation</p>
                  </CardContent>
                </Card>
              </div>

              <Card>
                <CardHeader>
                  <CardTitle className="text-xl">Key Features</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div className="p-4 bg-muted/30 rounded-md">
                      <h3 className="font-semibold text-foreground mb-2">Instant Verification</h3>
                      <p className="text-sm text-muted-foreground">
                        Verify your identity instantly without waiting for manual document checks
                      </p>
                    </div>
                    <div className="p-4 bg-muted/30 rounded-md">
                      <h3 className="font-semibold text-foreground mb-2">One-Time Process</h3>
                      <p className="text-sm text-muted-foreground">
                        Link once and use across all banking and financial services
                      </p>
                    </div>
                    <div className="p-4 bg-muted/30 rounded-md">
                      <h3 className="font-semibold text-foreground mb-2">Secure & Encrypted</h3>
                      <p className="text-sm text-muted-foreground">
                        Bank-grade encryption protects your Aadhaar data at all times
                      </p>
                    </div>
                    <div className="p-4 bg-muted/30 rounded-md">
                      <h3 className="font-semibold text-foreground mb-2">Multi-Account Support</h3>
                      <p className="text-sm text-muted-foreground">
                        Link your Aadhaar to multiple bank accounts as needed
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="dbt">
            <div className="space-y-8">
              <Card>
                <CardHeader>
                  <div className="mb-2">
                    <Badge className="bg-secondary text-secondary-foreground">
                      Direct Benefit Transfer System
                    </Badge>
                  </div>
                  <CardTitle className="text-2xl">What is DBT?</CardTitle>
                  <CardDescription className="text-base">
                    Understanding Direct Benefit Transfer and its advantages
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4 text-muted-foreground">
                  <p>
                    Direct Benefit Transfer (DBT) is a revolutionary initiative by the Government of India to transfer subsidies 
                    and benefits directly to citizens' bank accounts. It eliminates intermediaries, reduces leakage, and ensures 
                    that intended beneficiaries receive their entitlements promptly.
                  </p>
                  <p>
                    A DBT-enabled account is one that is registered with the DBT system and linked to your Aadhaar. 
                    This enables you to receive government benefits like LPG subsidies, scholarships, pensions, and MGNREGA wages 
                    directly into your account without any middlemen.
                  </p>
                </CardContent>
              </Card>

              <div className="mb-8">
                <img 
                  src={citizensImage} 
                  alt="Citizens using digital banking services" 
                  className="w-full h-auto rounded-lg shadow-md"
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <Card>
                  <CardHeader>
                    <Users className="h-8 w-8 text-secondary mb-2" />
                    <CardTitle className="text-xl">Benefits of DBT</CardTitle>
                  </CardHeader>
                  <CardContent className="text-sm text-muted-foreground space-y-2">
                    <p>• <strong>Direct Transfer:</strong> Money reaches you without intermediaries</p>
                    <p>• <strong>Faster Delivery:</strong> Reduced processing time for benefit disbursal</p>
                    <p>• <strong>Transparency:</strong> Track your benefits in real-time</p>
                    <p>• <strong>Reduced Corruption:</strong> Eliminates leakages in the system</p>
                    <p>• <strong>Targeted Delivery:</strong> Ensures benefits reach intended recipients</p>
                    <p>• <strong>Financial Inclusion:</strong> Encourages banking among all citizens</p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <Building2 className="h-8 w-8 text-secondary mb-2" />
                    <CardTitle className="text-xl">How to Enable DBT</CardTitle>
                  </CardHeader>
                  <CardContent className="text-sm text-muted-foreground space-y-2">
                    <p><strong>Step 1:</strong> Ensure Aadhaar is linked to your bank account</p>
                    <p><strong>Step 2:</strong> Visit DBT Bharat portal or your bank</p>
                    <p><strong>Step 3:</strong> Register for specific government schemes</p>
                    <p><strong>Step 4:</strong> Verify your Aadhaar-bank link through OTP</p>
                    <p><strong>Step 5:</strong> Receive confirmation of DBT activation</p>
                  </CardContent>
                </Card>
              </div>

              <Card>
                <CardHeader>
                  <CardTitle className="text-xl">Common DBT Schemes</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                    {[
                      { name: "LPG Subsidy", desc: "Direct subsidy for cooking gas" },
                      { name: "PM-KISAN", desc: "Financial support for farmers" },
                      { name: "Scholarships", desc: "Educational scholarships for students" },
                      { name: "MGNREGA", desc: "Wage payments for rural employment" },
                      { name: "Pensions", desc: "Old age, widow, and disability pensions" },
                      { name: "Maternity Benefits", desc: "Support for pregnant and lactating mothers" },
                    ].map((scheme, index) => (
                      <div key={index} className="p-4 bg-secondary/5 rounded-md border border-secondary/20">
                        <h3 className="font-semibold text-foreground mb-1">{scheme.name}</h3>
                        <p className="text-sm text-muted-foreground">{scheme.desc}</p>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
