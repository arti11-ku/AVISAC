import { useLanguage } from "@/contexts/LanguageContext";
import { SEO } from "@/components/SEO";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  CreditCard, 
  Landmark, 
  ShieldCheck, 
  Zap, 
  FileText, 
  MessageSquare, 
  Languages as LanguagesIcon,
  ArrowRight,
  CheckCircle2
} from "lucide-react";
import heroImage from "@assets/generated_images/Aadhaar_bank_linking_hero_29c57fb4.png";
import benefitsImage from "@assets/generated_images/DBT_benefits_icons_7e3bd46c.png";

export default function Home() {
  const { t } = useLanguage();

  const features = [
    {
      icon: CreditCard,
      title: t("features.aadhaar.title"),
      description: t("features.aadhaar.desc"),
      color: "text-primary",
    },
    {
      icon: Landmark,
      title: t("features.dbt.title"),
      description: t("features.dbt.desc"),
      color: "text-secondary",
    },
    {
      icon: ShieldCheck,
      title: t("features.difference.title"),
      description: t("features.difference.desc"),
      color: "text-accent",
    },
    {
      icon: FileText,
      title: t("features.forms.title"),
      description: t("features.forms.desc"),
      color: "text-primary",
    },
    {
      icon: MessageSquare,
      title: t("features.chatbot.title"),
      description: t("features.chatbot.desc"),
      color: "text-secondary",
    },
    {
      icon: LanguagesIcon,
      title: t("features.multilingual.title"),
      description: t("features.multilingual.desc"),
      color: "text-accent",
    },
  ];

  const benefits = [
    {
      icon: ShieldCheck,
      title: t("benefits.security.title"),
      description: t("benefits.security.desc"),
    },
    {
      icon: Zap,
      title: t("benefits.speed.title"),
      description: t("benefits.speed.desc"),
    },
    {
      icon: CheckCircle2,
      title: t("benefits.transparency.title"),
      description: t("benefits.transparency.desc"),
    },
  ];

  return (
    <div className="min-h-screen">
      <SEO 
        title={t("nav.home")}
        description="Learn about Aadhaar-linked and DBT-enabled bank accounts with step-by-step guidance in 22 Indian languages. AI-powered chatbot assistance for banking procedures."
      />
      <section 
        className="relative h-[60vh] sm:h-[70vh] flex items-center justify-center overflow-hidden"
        style={{
          backgroundImage: `linear-gradient(to bottom, rgba(255, 153, 51, 0.1), rgba(19, 136, 8, 0.1)), url(${heroImage})`,
          backgroundSize: "cover",
          backgroundPosition: "center",
        }}
      >
        <div className="absolute inset-0 bg-gradient-to-b from-black/40 via-black/30 to-black/50" />
        
        <div className="relative z-10 container mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <Badge className="mb-6 bg-primary/90 text-primary-foreground border-primary-border backdrop-blur-sm" data-testid="badge-hero">
            Digital India Initiative
          </Badge>
          <h1 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-bold text-white mb-6 drop-shadow-lg">
            {t("hero.title")}
          </h1>
          <p className="text-lg sm:text-xl text-white/90 mb-8 max-w-3xl mx-auto drop-shadow-md">
            {t("hero.subtitle")}
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/learn">
              <Button 
                size="lg" 
                variant="default"
                className="bg-primary/90 backdrop-blur-sm hover:bg-primary border border-primary-border text-base px-8 min-h-12"
                data-testid="button-learn-about-aadhaar"
              >
                {t("hero.cta.learn")}
                <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
            </Link>
            <Link href="/chatbot">
              <Button 
                size="lg" 
                variant="outline"
                className="bg-white/10 backdrop-blur-sm text-white border-white/30 hover:bg-white/20 text-base px-8 min-h-12"
                data-testid="button-ask-chatbot"
              >
                <MessageSquare className="mr-2 h-5 w-5" />
                {t("hero.cta.chat")}
              </Button>
            </Link>
          </div>
        </div>
      </section>

      <section className="py-12 sm:py-16 bg-background">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-2xl sm:text-3xl md:text-4xl font-bold text-foreground mb-4">
              {t("features.title")}
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {features.map((feature, index) => (
              <Card key={index} className="hover-elevate active-elevate-2 transition-all" data-testid={`card-feature-${index}`}>
                <CardHeader>
                  <div className="mb-4">
                    <feature.icon className={`h-12 w-12 ${feature.color}`} />
                  </div>
                  <CardTitle className="text-xl">{feature.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription className="text-base">{feature.description}</CardDescription>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      <section className="py-12 sm:py-16 bg-card">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-2xl sm:text-3xl md:text-4xl font-bold text-foreground mb-4">
              {t("benefits.title")}
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-5xl mx-auto">
            {benefits.map((benefit, index) => (
              <div key={index} className="text-center" data-testid={`benefit-${index}`}>
                <div className="mb-4 flex justify-center">
                  <div className="bg-secondary/10 p-4 rounded-lg">
                    <benefit.icon className="h-10 w-10 text-secondary" />
                  </div>
                </div>
                <h3 className="text-xl font-semibold text-foreground mb-2">{benefit.title}</h3>
                <p className="text-muted-foreground">{benefit.description}</p>
              </div>
            ))}
          </div>

          <div className="mt-12 flex justify-center">
            <img 
              src={benefitsImage} 
              alt="DBT Benefits Illustration" 
              className="max-w-full h-auto rounded-lg shadow-md"
            />
          </div>
        </div>
      </section>

      <section className="py-12 sm:py-16 bg-primary/5">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-2xl sm:text-3xl md:text-4xl font-bold text-foreground mb-6">
            Ready to Get Started?
          </h2>
          <p className="text-lg text-muted-foreground mb-8 max-w-2xl mx-auto">
            Explore detailed comparisons, get answers to your questions, or start chatting with our AI assistant
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/compare">
              <Button size="lg" variant="default" data-testid="button-compare-accounts">
                Compare Account Types
              </Button>
            </Link>
            <Link href="/faq">
              <Button size="lg" variant="outline" data-testid="button-view-faq">
                View FAQ
              </Button>
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}
