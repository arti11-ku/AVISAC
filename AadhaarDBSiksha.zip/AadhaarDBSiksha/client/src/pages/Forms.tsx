import { useLanguage } from "@/contexts/LanguageContext";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { CheckCircle2, FileText } from "lucide-react";

export default function Forms() {
  const { t } = useLanguage();

  const forms = [
    {
      title: t("forms.linking.title"),
      steps: [
        t("forms.linking.step1"),
        t("forms.linking.step2"),
        t("forms.linking.step3"),
        t("forms.linking.step4"),
      ],
      color: "primary",
    },
    {
      title: t("forms.dbt.title"),
      steps: [
        t("forms.dbt.step1"),
        t("forms.dbt.step2"),
        t("forms.dbt.step3"),
        t("forms.dbt.step4"),
      ],
      color: "secondary",
    },
  ];

  return (
    <div className="min-h-screen py-8 sm:py-12 bg-background">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 max-w-5xl">
        <div className="text-center mb-12">
          <FileText className="h-16 w-16 text-primary mx-auto mb-4" />
          <h1 className="text-3xl sm:text-4xl md:text-5xl font-bold text-foreground mb-4">
            {t("forms.title")}
          </h1>
          <p className="text-lg text-muted-foreground">
            {t("forms.subtitle")}
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {forms.map((form, formIndex) => (
            <Card key={formIndex} className="hover-elevate transition-all" data-testid={`card-form-${formIndex}`}>
              <CardHeader>
                <div className="mb-2">
                  <Badge 
                    className={
                      form.color === "primary" 
                        ? "bg-primary text-primary-foreground" 
                        : "bg-secondary text-secondary-foreground"
                    }
                  >
                    Step-by-Step Guide
                  </Badge>
                </div>
                <CardTitle className="text-xl">{form.title}</CardTitle>
                <CardDescription>Follow these steps carefully</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {form.steps.map((step, stepIndex) => (
                    <div 
                      key={stepIndex} 
                      className="flex items-start gap-3 p-3 rounded-md bg-muted/30"
                      data-testid={`form-step-${formIndex}-${stepIndex}`}
                    >
                      <div 
                        className={`flex-shrink-0 w-8 h-8 rounded-full flex items-center justify-center text-sm font-semibold ${
                          form.color === "primary" 
                            ? "bg-primary text-primary-foreground" 
                            : "bg-secondary text-secondary-foreground"
                        }`}
                      >
                        {stepIndex + 1}
                      </div>
                      <p className="text-sm text-foreground pt-1">{step}</p>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="mt-12 grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <CheckCircle2 className="h-5 w-5 text-secondary" />
                Important Tips
              </CardTitle>
            </CardHeader>
            <CardContent className="text-sm text-muted-foreground space-y-2">
              <p>• Keep your Aadhaar card handy</p>
              <p>• Ensure mobile number is linked to Aadhaar</p>
              <p>• Verify all details before submission</p>
              <p>• Keep acknowledgment receipts safe</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <CheckCircle2 className="h-5 w-5 text-secondary" />
                Required Documents
              </CardTitle>
            </CardHeader>
            <CardContent className="text-sm text-muted-foreground space-y-2">
              <p>• Original Aadhaar card or e-Aadhaar</p>
              <p>• Bank account passbook or statement</p>
              <p>• Valid mobile number</p>
              <p>• Identity proof (if required)</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <CheckCircle2 className="h-5 w-5 text-secondary" />
                Common Mistakes
              </CardTitle>
            </CardHeader>
            <CardContent className="text-sm text-muted-foreground space-y-2">
              <p>• Entering incorrect Aadhaar number</p>
              <p>• Name mismatch between bank and Aadhaar</p>
              <p>• Using outdated mobile number</p>
              <p>• Not completing OTP verification</p>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
