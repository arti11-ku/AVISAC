import { useLanguage } from "@/contexts/LanguageContext";
import { SEO } from "@/components/SEO";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { Card } from "@/components/ui/card";
import { MessageSquare } from "lucide-react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";

export default function FAQ() {
  const { t } = useLanguage();

  const faqs = [
    {
      question: t("faq.q1"),
      answer: t("faq.a1"),
    },
    {
      question: t("faq.q2"),
      answer: t("faq.a2"),
    },
    {
      question: t("faq.q3"),
      answer: t("faq.a3"),
    },
    {
      question: t("faq.q4"),
      answer: t("faq.a4"),
    },
    {
      question: t("faq.q5"),
      answer: t("faq.a5"),
    },
    {
      question: t("faq.q6"),
      answer: t("faq.a6"),
    },
  ];

  return (
    <div className="min-h-screen py-8 sm:py-12 bg-background">
      <SEO 
        title={t("faq.title")}
        description="Frequently asked questions about Aadhaar linking and DBT-enabled bank accounts. Get answers to common queries about government benefits and banking procedures."
      />
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 max-w-4xl">
        <div className="text-center mb-12">
          <h1 className="text-3xl sm:text-4xl md:text-5xl font-bold text-foreground mb-4">
            {t("faq.title")}
          </h1>
          <p className="text-lg text-muted-foreground">
            Find answers to common questions about Aadhaar and DBT
          </p>
        </div>

        <Card className="p-6 sm:p-8">
          <Accordion type="single" collapsible className="w-full">
            {faqs.map((faq, index) => (
              <AccordionItem key={index} value={`item-${index}`} data-testid={`faq-item-${index}`}>
                <AccordionTrigger className="text-left text-base sm:text-lg font-semibold">
                  {faq.question}
                </AccordionTrigger>
                <AccordionContent className="text-muted-foreground text-base">
                  {faq.answer}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </Card>

        <div className="mt-12 bg-primary/5 rounded-lg p-8 text-center">
          <MessageSquare className="h-12 w-12 text-primary mx-auto mb-4" />
          <h2 className="text-2xl font-bold text-foreground mb-2">
            Still Have Questions?
          </h2>
          <p className="text-muted-foreground mb-6">
            Our AI-powered chatbot is available 24/7 to answer your questions in your preferred language
          </p>
          <Link href="/chatbot">
            <Button size="lg" data-testid="button-ask-chatbot-faq">
              Ask Our Chatbot
            </Button>
          </Link>
        </div>
      </div>
    </div>
  );
}
