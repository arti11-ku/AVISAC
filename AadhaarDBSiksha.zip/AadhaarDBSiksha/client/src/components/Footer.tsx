import { useLanguage } from "@/contexts/LanguageContext";
import { Landmark } from "lucide-react";

export function Footer() {
  const { t } = useLanguage();

  return (
    <footer className="border-t bg-card mt-16">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex flex-col items-center gap-4 text-center">
          <div className="flex items-center gap-2">
            <Landmark className="h-6 w-6 text-primary" />
            <span className="font-semibold text-foreground">Digital India Portal</span>
          </div>
          <p className="text-sm text-muted-foreground max-w-2xl">
            {t("footer.tagline")}
          </p>
          <p className="text-xs text-muted-foreground">
            {t("footer.disclaimer")}
          </p>
          <p className="text-xs text-muted-foreground">
            © 2024 Educational Platform. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
}
