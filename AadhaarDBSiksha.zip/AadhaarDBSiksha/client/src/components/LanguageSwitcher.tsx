import { useLanguage } from "@/contexts/LanguageContext";
import { SUPPORTED_LANGUAGES } from "@shared/schema";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Languages, Check } from "lucide-react";

export function LanguageSwitcher() {
  const { currentLanguage, setLanguage } = useLanguage();

  const currentLangData = SUPPORTED_LANGUAGES.find(
    (lang) => lang.code === currentLanguage
  );

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="outline" size="default" data-testid="button-language-switcher">
          <Languages className="h-4 w-4 mr-2" />
          <span className="hidden sm:inline">{currentLangData?.nativeName}</span>
          <span className="sm:hidden">{currentLangData?.code.toUpperCase()}</span>
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="max-h-96 overflow-y-auto">
        {SUPPORTED_LANGUAGES.map((lang) => (
          <DropdownMenuItem
            key={lang.code}
            onClick={() => setLanguage(lang.code)}
            className="gap-2"
            data-testid={`menu-item-language-${lang.code}`}
          >
            {currentLanguage === lang.code && (
              <Check className="h-4 w-4 text-secondary" />
            )}
            <span className={currentLanguage !== lang.code ? "ml-6" : ""}>
              {lang.nativeName} ({lang.name})
            </span>
          </DropdownMenuItem>
        ))}
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
