import { Link, useLocation } from "wouter";
import { useLanguage } from "@/contexts/LanguageContext";
import { LanguageSwitcher } from "@/components/LanguageSwitcher";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { Menu, Landmark } from "lucide-react";

export function Header() {
  const { t } = useLanguage();
  const [location] = useLocation();

  const navItems = [
    { path: "/", label: t("nav.home") },
    { path: "/learn", label: t("nav.learn") },
    { path: "/compare", label: t("nav.compare") },
    { path: "/chatbot", label: t("nav.chatbot") },
    { path: "/forms", label: t("nav.forms") },
    { path: "/faq", label: t("nav.faq") },
  ];

  return (
    <header className="sticky top-0 z-50 w-full border-b bg-card/95 backdrop-blur supports-[backdrop-filter]:bg-card/80">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex h-16 sm:h-20 items-center justify-between gap-4">
          <Link href="/" className="flex items-center gap-2 hover-elevate active-elevate-2 px-3 py-2 rounded-md" data-testid="link-home-logo">
            <Landmark className="h-8 w-8 text-primary" />
            <div className="hidden sm:block">
              <div className="font-semibold text-base text-foreground">Digital India</div>
              <div className="text-xs text-muted-foreground">Aadhaar & DBT Portal</div>
            </div>
          </Link>

          <nav className="hidden md:flex items-center gap-1">
            {navItems.map((item) => (
              <Link 
                key={item.path} 
                href={item.path}
                className={`px-4 py-2 rounded-md text-sm font-medium transition-colors hover-elevate active-elevate-2 ${
                  location === item.path
                    ? "bg-accent text-accent-foreground"
                    : "text-foreground"
                }`}
                data-testid={`link-nav-${item.path.slice(1) || "home"}`}
              >
                {item.label}
              </Link>
            ))}
          </nav>

          <div className="flex items-center gap-2">
            <LanguageSwitcher />

            <Sheet>
              <SheetTrigger asChild className="md:hidden">
                <Button variant="ghost" size="icon" data-testid="button-mobile-menu">
                  <Menu className="h-5 w-5" />
                </Button>
              </SheetTrigger>
              <SheetContent side="right" className="w-64">
                <nav className="flex flex-col gap-2 mt-8">
                  {navItems.map((item) => (
                    <Link 
                      key={item.path} 
                      href={item.path}
                      className={`px-4 py-3 rounded-md text-base font-medium transition-colors hover-elevate active-elevate-2 block ${
                        location === item.path
                          ? "bg-accent text-accent-foreground"
                          : "text-foreground"
                      }`}
                      data-testid={`link-mobile-nav-${item.path.slice(1) || "home"}`}
                    >
                      {item.label}
                    </Link>
                  ))}
                </nav>
              </SheetContent>
            </Sheet>
          </div>
        </div>
      </div>
    </header>
  );
}
