import { createContext, useContext, useState, ReactNode } from "react";
import { SUPPORTED_LANGUAGES, type LanguageCode } from "@shared/schema";

interface LanguageContextType {
  currentLanguage: LanguageCode;
  setLanguage: (lang: LanguageCode) => void;
  t: (key: string) => string;
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

const translations: Record<string, Record<string, string>> = {
  en: {
    // Header
    "nav.home": "Home",
    "nav.learn": "Learn",
    "nav.compare": "Compare",
    "nav.chatbot": "Chatbot",
    "nav.forms": "Forms",
    "nav.resources": "Resources",
    "nav.faq": "FAQ",
    
    // Hero
    "hero.title": "Understanding Aadhaar & DBT Banking",
    "hero.subtitle": "Learn the difference between Aadhaar-linked and DBT-enabled bank accounts with step-by-step guidance in your language",
    "hero.cta.learn": "Learn About Aadhaar",
    "hero.cta.chat": "Ask Our Chatbot",
    
    // Features
    "features.title": "What You'll Learn",
    "features.aadhaar.title": "Aadhaar-Linked Accounts",
    "features.aadhaar.desc": "Understand how linking your Aadhaar to your bank account works and why it's important",
    "features.dbt.title": "DBT-Enabled Accounts",
    "features.dbt.desc": "Learn how Direct Benefit Transfer accounts help you receive government benefits directly",
    "features.difference.title": "Key Differences",
    "features.difference.desc": "Compare features, benefits, and procedures side-by-side",
    "features.forms.title": "Form Assistance",
    "features.forms.desc": "Get step-by-step help filling out banking and Aadhaar forms",
    "features.chatbot.title": "24/7 AI Assistant",
    "features.chatbot.desc": "Ask questions anytime in your preferred language",
    "features.multilingual.title": "22 Languages",
    "features.multilingual.desc": "Access all content in any of India's 22 official languages",
    
    // Comparison
    "compare.title": "Aadhaar-Linked vs DBT-Enabled Accounts",
    "compare.subtitle": "Understanding the key differences",
    "compare.aadhaar": "Aadhaar-Linked Account",
    "compare.dbt": "DBT-Enabled Account",
    "compare.purpose.label": "Purpose",
    "compare.purpose.aadhaar": "Links Aadhaar number to bank account for identity verification",
    "compare.purpose.dbt": "Enables direct receipt of government subsidies and benefits",
    "compare.benefits.label": "Key Benefits",
    "compare.benefits.aadhaar": "KYC compliance, secure authentication, mandatory for many services",
    "compare.benefits.dbt": "Direct transfers, no middlemen, faster delivery, transparency",
    "compare.requirement.label": "Requirement",
    "compare.requirement.aadhaar": "Required for most government services and financial transactions",
    "compare.requirement.dbt": "Required to receive government benefits like LPG subsidy, scholarships",
    "compare.process.label": "Setup Process",
    "compare.process.aadhaar": "Submit Aadhaar number at bank branch or online banking",
    "compare.process.dbt": "Complete Aadhaar linking, then register for DBT schemes",
    
    // Benefits
    "benefits.title": "Benefits of DBT-Enabled Accounts",
    "benefits.security.title": "Enhanced Security",
    "benefits.security.desc": "Biometric authentication ensures benefits reach the right person",
    "benefits.speed.title": "Fast Transfers",
    "benefits.speed.desc": "Direct transfers eliminate delays and middlemen",
    "benefits.transparency.title": "Complete Transparency",
    "benefits.transparency.desc": "Track your benefits and subsidies in real-time",
    
    // FAQ
    "faq.title": "Frequently Asked Questions",
    "faq.q1": "What is the difference between Aadhaar-linked and DBT-enabled accounts?",
    "faq.a1": "An Aadhaar-linked account simply has your Aadhaar number associated with it for identity verification. A DBT-enabled account goes further by being registered to receive government benefits and subsidies directly through the Direct Benefit Transfer system.",
    "faq.q2": "Do I need both types of accounts?",
    "faq.a2": "You don't need two separate accounts. A single bank account can be both Aadhaar-linked AND DBT-enabled. First link your Aadhaar, then register for DBT schemes to make it DBT-enabled.",
    "faq.q3": "How do I link my Aadhaar to my bank account?",
    "faq.a3": "You can link Aadhaar by visiting your bank branch with your Aadhaar card, using online banking/mobile banking, or through an ATM. The process is free and usually takes a few minutes.",
    "faq.q4": "What government benefits can I receive through DBT?",
    "faq.a4": "Common benefits include LPG subsidy, MGNREGA wages, pension payments, scholarships, PM-KISAN payments, and various state government schemes. The list continues to grow.",
    "faq.q5": "Is my Aadhaar information safe when linked to my bank account?",
    "faq.a5": "Yes, banks use secure encryption and follow strict RBI guidelines. Only your Aadhaar number is linked, not your biometric data. The link helps verify your identity and prevent fraud.",
    "faq.q6": "Can I have multiple bank accounts linked to my Aadhaar?",
    "faq.a6": "Yes, you can link your Aadhaar to multiple bank accounts. However, for DBT benefits, you should designate one primary account where you want to receive government transfers.",
    
    // Resources
    "resources.title": "Helpful Resources",
    "resources.official.title": "Official Government Links",
    "resources.official.uidai": "UIDAI Official Website",
    "resources.official.dbt": "DBT Bharat Portal",
    "resources.official.pmjdy": "PM Jan Dhan Yojana",
    "resources.guides.title": "Downloadable Guides",
    "resources.guides.linking": "Step-by-step Aadhaar Linking Guide",
    "resources.guides.dbt": "DBT Registration Guide",
    "resources.guides.forms": "Common Forms Reference",
    
    // Chatbot
    "chatbot.title": "AI Assistant",
    "chatbot.subtitle": "Ask me anything about Aadhaar and DBT",
    "chatbot.placeholder": "Type your question here...",
    "chatbot.send": "Send",
    "chatbot.welcome": "Hello! I'm here to help you understand Aadhaar-linked and DBT-enabled bank accounts. Ask me anything!",
    "chatbot.thinking": "Thinking...",
    "chatbot.error": "Sorry, I encountered an error. Please try again.",
    
    // Forms
    "forms.title": "Government Form Assistance",
    "forms.subtitle": "Step-by-step guidance for common banking and Aadhaar forms",
    "forms.linking.title": "Aadhaar-Bank Account Linking Form",
    "forms.linking.step1": "Visit your bank branch or log into online banking",
    "forms.linking.step2": "Provide your Aadhaar number (12 digits)",
    "forms.linking.step3": "Verify your details match Aadhaar records",
    "forms.linking.step4": "Submit and receive confirmation",
    "forms.dbt.title": "DBT Registration Form",
    "forms.dbt.step1": "Ensure Aadhaar is linked to your bank account",
    "forms.dbt.step2": "Visit the DBT portal or your bank",
    "forms.dbt.step3": "Select the schemes you want to enroll in",
    "forms.dbt.step4": "Provide necessary documents and submit",
    
    // Footer
    "footer.tagline": "Empowering citizens through Digital India",
    "footer.disclaimer": "This is an educational platform. For official procedures, please visit government websites.",
  },
  hi: {
    // Header
    "nav.home": "होम",
    "nav.learn": "सीखें",
    "nav.compare": "तुलना करें",
    "nav.chatbot": "चैटबॉट",
    "nav.forms": "फॉर्म",
    "nav.resources": "संसाधन",
    "nav.faq": "अक्सर पूछे जाने वाले प्रश्न",
    
    // Hero
    "hero.title": "आधार और डीबीटी बैंकिंग को समझें",
    "hero.subtitle": "अपनी भाषा में चरण-दर-चरण मार्गदर्शन के साथ आधार-लिंक्ड और डीबीटी-सक्षम बैंक खातों के बीच का अंतर जानें",
    "hero.cta.learn": "आधार के बारे में जानें",
    "hero.cta.chat": "हमारे चैटबॉट से पूछें",
    
    // Features
    "features.title": "आप क्या सीखेंगे",
    "features.aadhaar.title": "आधार-लिंक्ड खाते",
    "features.aadhaar.desc": "समझें कि आपके बैंक खाते से आधार को लिंक करना कैसे काम करता है और यह क्यों महत्वपूर्ण है",
    "features.dbt.title": "डीबीटी-सक्षम खाते",
    "features.dbt.desc": "जानें कि प्रत्यक्ष लाभ हस्तांतरण खाते आपको सरकारी लाभ सीधे प्राप्त करने में कैसे मदद करते हैं",
    "features.difference.title": "मुख्य अंतर",
    "features.difference.desc": "सुविधाओं, लाभों और प्रक्रियाओं की साथ-साथ तुलना करें",
    "features.forms.title": "फॉर्म सहायता",
    "features.forms.desc": "बैंकिंग और आधार फॉर्म भरने में चरण-दर-चरण सहायता प्राप्त करें",
    "features.chatbot.title": "24/7 एआई सहायक",
    "features.chatbot.desc": "अपनी पसंदीदा भाषा में किसी भी समय प्रश्न पूछें",
    "features.multilingual.title": "22 भाषाएं",
    "features.multilingual.desc": "भारत की 22 आधिकारिक भाषाओं में से किसी में भी सभी सामग्री तक पहुंचें",
    
    // Comparison
    "compare.title": "आधार-लिंक्ड बनाम डीबीटी-सक्षम खाते",
    "compare.subtitle": "मुख्य अंतर को समझना",
    "compare.aadhaar": "आधार-लिंक्ड खाता",
    "compare.dbt": "डीबीटी-सक्षम खाता",
    "compare.purpose.label": "उद्देश्य",
    "compare.purpose.aadhaar": "पहचान सत्यापन के लिए आधार संख्या को बैंक खाते से लिंक करता है",
    "compare.purpose.dbt": "सरकारी सब्सिडी और लाभों की सीधी प्राप्ति को सक्षम बनाता है",
    "compare.benefits.label": "मुख्य लाभ",
    "compare.benefits.aadhaar": "केवाईसी अनुपालन, सुरक्षित प्रमाणीकरण, कई सेवाओं के लिए अनिवार्य",
    "compare.benefits.dbt": "प्रत्यक्ष हस्तांतरण, कोई बिचौलिए नहीं, तेज़ वितरण, पारदर्शिता",
    "compare.requirement.label": "आवश्यकता",
    "compare.requirement.aadhaar": "अधिकांश सरकारी सेवाओं और वित्तीय लेनदेन के लिए आवश्यक",
    "compare.requirement.dbt": "एलपीजी सब्सिडी, छात्रवृत्ति जैसे सरकारी लाभ प्राप्त करने के लिए आवश्यक",
    "compare.process.label": "सेटअप प्रक्रिया",
    "compare.process.aadhaar": "बैंक शाखा या ऑनलाइन बैंकिंग में आधार संख्या जमा करें",
    "compare.process.dbt": "आधार लिंकिंग पूरा करें, फिर डीबीटी योजनाओं के लिए पंजीकरण करें",
    
    // Benefits
    "benefits.title": "डीबीटी-सक्षम खातों के लाभ",
    "benefits.security.title": "बढ़ी हुई सुरक्षा",
    "benefits.security.desc": "बायोमेट्रिक प्रमाणीकरण यह सुनिश्चित करता है कि लाभ सही व्यक्ति तक पहुंचे",
    "benefits.speed.title": "तेज़ हस्तांतरण",
    "benefits.speed.desc": "प्रत्यक्ष हस्तांतरण देरी और बिचौलियों को समाप्त करता है",
    "benefits.transparency.title": "पूर्ण पारदर्शिता",
    "benefits.transparency.desc": "अपने लाभों और सब्सिडी को वास्तविक समय में ट्रैक करें",
    
    // FAQ
    "faq.title": "अक्सर पूछे जाने वाले प्रश्न",
    "faq.q1": "आधार-लिंक्ड और डीबीटी-सक्षम खातों में क्या अंतर है?",
    "faq.a1": "आधार-लिंक्ड खाते में पहचान सत्यापन के लिए आपका आधार नंबर जुड़ा होता है। डीबीटी-सक्षम खाता आगे बढ़कर प्रत्यक्ष लाभ हस्तांतरण प्रणाली के माध्यम से सरकारी लाभ और सब्सिडी सीधे प्राप्त करने के लिए पंजीकृत होता है।",
    "faq.q2": "क्या मुझे दोनों प्रकार के खातों की आवश्यकता है?",
    "faq.a2": "आपको दो अलग खातों की आवश्यकता नहीं है। एक ही बैंक खाता आधार-लिंक्ड और डीबीटी-सक्षम दोनों हो सकता है। पहले अपना आधार लिंक करें, फिर डीबीटी योजनाओं के लिए पंजीकरण करें।",
    "faq.q3": "मैं अपने बैंक खाते से आधार कैसे लिंक करूं?",
    "faq.a3": "आप अपने आधार कार्ड के साथ बैंक शाखा जाकर, ऑनलाइन बैंकिंग/मोबाइल बैंकिंग का उपयोग करके, या एटीएम के माध्यम से आधार लिंक कर सकते हैं। यह प्रक्रिया मुफ्त है और आमतौर पर कुछ मिनट लगते हैं।",
    "faq.q4": "मैं डीबीटी के माध्यम से कौन से सरकारी लाभ प्राप्त कर सकता हूं?",
    "faq.a4": "सामान्य लाभों में एलपीजी सब्सिडी, मनरेगा मजदूरी, पेंशन भुगतान, छात्रवृत्ति, पीएम-किसान भुगतान और विभिन्न राज्य सरकारी योजनाएं शामिल हैं।",
    "faq.q5": "क्या मेरी आधार जानकारी बैंक खाते से लिंक होने पर सुरक्षित है?",
    "faq.a5": "हां, बैंक सुरक्षित एन्क्रिप्शन का उपयोग करते हैं और सख्त आरबीआई दिशानिर्देशों का पालन करते हैं। केवल आपका आधार नंबर लिंक होता है, आपका बायोमेट्रिक डेटा नहीं।",
    "faq.q6": "क्या मैं अपने आधार से कई बैंक खाते लिंक कर सकता हूं?",
    "faq.a6": "हां, आप अपने आधार को कई बैंक खातों से लिंक कर सकते हैं। हालांकि, डीबीटी लाभों के लिए, आपको एक प्राथमिक खाता नामित करना चाहिए जहां आप सरकारी हस्तांतरण प्राप्त करना चाहते हैं।",
    
    // Resources
    "resources.title": "सहायक संसाधन",
    "resources.official.title": "आधिकारिक सरकारी लिंक",
    "resources.official.uidai": "यूआईडीएआई आधिकारिक वेबसाइट",
    "resources.official.dbt": "डीबीटी भारत पोर्टल",
    "resources.official.pmjdy": "पीएम जन धन योजना",
    "resources.guides.title": "डाउनलोड करने योग्य गाइड",
    "resources.guides.linking": "चरण-दर-चरण आधार लिंकिंग गाइड",
    "resources.guides.dbt": "डीबीटी पंजीकरण गाइड",
    "resources.guides.forms": "सामान्य फॉर्म संदर्भ",
    
    // Chatbot
    "chatbot.title": "एआई सहायक",
    "chatbot.subtitle": "आधार और डीबीटी के बारे में मुझसे कुछ भी पूछें",
    "chatbot.placeholder": "अपना प्रश्न यहां लिखें...",
    "chatbot.send": "भेजें",
    "chatbot.welcome": "नमस्ते! मैं आपको आधार-लिंक्ड और डीबीटी-सक्षम बैंक खातों को समझने में मदद करने के लिए यहां हूं। मुझसे कुछ भी पूछें!",
    "chatbot.thinking": "सोच रहा हूं...",
    "chatbot.error": "क्षमा करें, मुझे एक त्रुटि का सामना करना पड़ा। कृपया पुन: प्रयास करें।",
    
    // Forms
    "forms.title": "सरकारी फॉर्म सहायता",
    "forms.subtitle": "सामान्य बैंकिंग और आधार फॉर्म के लिए चरण-दर-चरण मार्गदर्शन",
    "forms.linking.title": "आधार-बैंक खाता लिंकिंग फॉर्म",
    "forms.linking.step1": "अपनी बैंक शाखा पर जाएं या ऑनलाइन बैंकिंग में लॉग इन करें",
    "forms.linking.step2": "अपना आधार नंबर प्रदान करें (12 अंक)",
    "forms.linking.step3": "सत्यापित करें कि आपका विवरण आधार रिकॉर्ड से मेल खाता है",
    "forms.linking.step4": "जमा करें और पुष्टि प्राप्त करें",
    "forms.dbt.title": "डीबीटी पंजीकरण फॉर्म",
    "forms.dbt.step1": "सुनिश्चित करें कि आधार आपके बैंक खाते से लिंक है",
    "forms.dbt.step2": "डीबीटी पोर्टल या अपने बैंक पर जाएं",
    "forms.dbt.step3": "उन योजनाओं का चयन करें जिनमें आप नामांकन करना चाहते हैं",
    "forms.dbt.step4": "आवश्यक दस्तावेज़ प्रदान करें और जमा करें",
    
    // Footer
    "footer.tagline": "डिजिटल इंडिया के माध्यम से नागरिकों को सशक्त बनाना",
    "footer.disclaimer": "यह एक शैक्षिक मंच है। आधिकारिक प्रक्रियाओं के लिए, कृपया सरकारी वेबसाइटों पर जाएं।",
  },
};

export function LanguageProvider({ children }: { children: ReactNode }) {
  const [currentLanguage, setCurrentLanguage] = useState<LanguageCode>("en");

  const t = (key: string): string => {
    return translations[currentLanguage]?.[key] || translations.en[key] || key;
  };

  const setLanguage = (lang: LanguageCode) => {
    setCurrentLanguage(lang);
  };

  return (
    <LanguageContext.Provider value={{ currentLanguage, setLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
}

export function useLanguage() {
  const context = useContext(LanguageContext);
  if (!context) {
    throw new Error("useLanguage must be used within a LanguageProvider");
  }
  return context;
}
