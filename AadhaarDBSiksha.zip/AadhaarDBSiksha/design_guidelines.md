# Design Guidelines: Aadhaar-DBT Educational Platform

## Design Approach
**Reference-Based Approach**: Drawing inspiration from Digital India portal and MyGov.in - established government service platforms known for accessible, multilingual interfaces. Focus on clarity, accessibility, and trust-building visual design suitable for government educational content.

## Color Palette (User Specified)
- **Primary**: #FF9933 (Saffron) - Headers, primary CTAs, important highlights
- **Secondary**: #138808 (Green) - Success states, positive actions, verification indicators
- **Accent**: #000080 (Navy Blue) - Links, interactive elements, secondary CTAs
- **Background**: #F8F9FA (Light Grey) - Page background, card containers
- **Text**: #2C3E50 (Dark Blue-Grey) - Body text, headings
- **Success**: #28A745 - Form completions, successful actions

## Typography
- **Primary Font**: Noto Sans (excellent Devanagari and regional script support)
- **Secondary Font**: Inter (fallback for Latin scripts)
- **Hierarchy**:
  - H1: 2.5rem (40px) / 3rem (48px) on desktop - Page titles
  - H2: 2rem (32px) - Section headings
  - H3: 1.5rem (24px) - Card titles, subsections
  - Body: 1rem (16px) - Standard content
  - Small: 0.875rem (14px) - Captions, metadata

## Layout System
**Spacing Units**: Tailwind units of 2, 4, 6, 8, 12, 16 for consistent rhythm
- Mobile padding: p-4, p-6
- Desktop padding: p-8, p-12, p-16
- Section spacing: mb-8, mb-12, mb-16
- Card gaps: gap-4, gap-6

## Core Components

### Header/Navigation
- Persistent language switcher (dropdown with all 22 languages, flag icons optional)
- Logo with "Government of India" emblem styling
- Primary navigation: Home, Learn, Compare, Chatbot, Forms, Resources
- Mobile: Hamburger menu with full-screen overlay
- Height: h-16 on mobile, h-20 on desktop

### Hero Section
- **Layout**: Full-width banner with gradient overlay (saffron to green gradient at 10% opacity)
- **Content**: Centered text with primary heading, subtitle, dual CTAs ("Learn About Aadhaar" + "Start Chatbot")
- **Background**: Illustration/image depicting digital banking/Aadhaar card (abstract, modern)
- **Height**: 60vh on mobile, 70vh on desktop
- **CTA Buttons**: Large (px-8 py-4), with blurred background overlay

### Information Cards
- **Style**: White background with subtle shadow (shadow-md), rounded corners (rounded-lg)
- **Padding**: p-6 on mobile, p-8 on desktop
- **Layout**: Grid system - 1 column mobile, 2 columns tablet, 3 columns desktop
- **Elements**: Icon at top (64px), heading (H3), description text, "Learn More" link

### Comparison Section
- **Layout**: Side-by-side two-column comparison table
- **Style**: Bordered cards with alternating row backgrounds (#F8F9FA / white)
- **Headers**: Saffron background for "Aadhaar Linked", Green for "DBT Enabled"
- **Mobile**: Stacked cards instead of table

### Chatbot Interface
- **Position**: Fixed bottom-right on desktop, full-screen modal on mobile
- **Style**: Rounded container (rounded-2xl), shadow-2xl
- **Header**: Navy blue with white text, close button
- **Messages**: User messages align right (saffron background), bot messages left (white with border)
- **Input**: Sticky bottom with send button (navy blue)

### Form Guidance Section
- **Layout**: Step-by-step wizard interface
- **Progress Indicator**: Horizontal stepper with saffron active state
- **Form Fields**: High contrast borders, large touch targets (h-12)
- **Helper Text**: Below each field in smaller text, icons for validation

### Language Switcher
- **Desktop**: Dropdown in top-right corner with country flags + language names
- **Mobile**: Bottom sheet with full list, search capability
- **Active State**: Green checkmark, saffron highlight

## Images

### Hero Image
Large background image showing digital India theme - could be:
- Abstract illustration of Aadhaar card with banking symbols
- Modern digital interface with security elements
- People using digital banking services (diverse representation)
- Gradient overlay to ensure text readability

### Section Images
- **Comparison Section**: Side-by-side icons/illustrations showing the two account types
- **Benefits Section**: Icon illustrations for each benefit (security, speed, transparency)
- **Form Guide**: Screenshots or simplified mockups of actual government forms

## Accessibility Features
- Minimum contrast ratio 4.5:1 for all text
- Focus indicators: 3px saffron outline on all interactive elements
- ARIA labels for language switcher and chatbot
- Keyboard navigation support throughout
- Screen reader optimized headings and landmarks
- Font size adjustment controls (A-, A, A+)

## Mobile-First Responsive Breakpoints
- Mobile: base (320px-640px) - Single column, stacked navigation
- Tablet: md (768px-1024px) - Two columns, condensed header
- Desktop: lg (1024px+) - Full layout, multi-column grids

## Animation Guidelines
- Minimal animations - use sparingly for feedback only
- Language switch: 200ms fade transition
- Card hover: Subtle lift (translateY -2px) with shadow increase
- Chatbot open/close: 300ms slide-up animation
- No scroll-triggered animations

## Key UX Principles
- **Trust Building**: Government badge/seal, official color scheme, clear sourcing
- **Clarity First**: Plain language, visual hierarchy, progressive disclosure
- **Multilingual Excellence**: Font rendering quality across all scripts, RTL support where needed
- **Guided Learning**: Step-by-step progressions, clear next actions, contextual help throughout