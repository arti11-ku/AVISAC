import OpenAI from "openai";

// the newest OpenAI model is "gpt-5" which was released August 7, 2025. do not change this unless explicitly requested by the user
const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

const SYSTEM_PROMPT = `You are a helpful AI assistant for an educational platform about Aadhaar and Direct Benefit Transfer (DBT) banking in India. 

Your role is to:
1. Explain the difference between Aadhaar-linked and DBT-enabled bank accounts clearly
2. Guide users through the process of linking Aadhaar to their bank accounts
3. Help users understand how to register for DBT schemes
4. Provide step-by-step instructions for filling out government forms
5. Answer questions about government benefits, subsidies, and schemes
6. Explain the security and privacy aspects of Aadhaar

Key information to know:
- Aadhaar-linked account: Bank account with Aadhaar number linked for KYC and identity verification
- DBT-enabled account: Account registered to receive direct government benefits and subsidies
- A single account can be both Aadhaar-linked AND DBT-enabled
- Common DBT schemes: LPG subsidy, PM-KISAN, MGNREGA, scholarships, pensions
- Aadhaar linking is mandatory for most government services and financial transactions
- DBT eliminates middlemen and ensures direct, transparent benefit delivery

Guidelines:
- Be clear, concise, and friendly
- Use simple language suitable for all education levels
- Provide step-by-step instructions when asked
- If asked about specific procedures, give detailed steps
- Always prioritize accuracy over speed
- If you're unsure about something, acknowledge it
- Encourage users to verify critical information with official government sources`;

export async function getChatResponse(
  userMessage: string,
  language: string
): Promise<string> {
  try {
    const languageInstruction = language !== "en" 
      ? `\n\nIMPORTANT: Respond in ${language} language. Translate your response appropriately while maintaining clarity and accuracy.`
      : "";

    const response = await openai.chat.completions.create({
      model: "gpt-5",
      messages: [
        {
          role: "system",
          content: SYSTEM_PROMPT + languageInstruction,
        },
        {
          role: "user",
          content: userMessage,
        },
      ],
      max_completion_tokens: 2048,
    });

    return response.choices[0].message.content || "I apologize, but I couldn't generate a response. Please try again.";
  } catch (error) {
    console.error("OpenAI API error:", error);
    throw new Error("Failed to get chat response from AI");
  }
}
