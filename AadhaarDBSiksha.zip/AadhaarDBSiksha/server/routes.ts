import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { getChatResponse } from "./openai";
import { insertChatMessageSchema, SUPPORTED_LANGUAGES, type LanguageCode } from "@shared/schema";
import { z } from "zod";
import { randomUUID } from "crypto";

const supportedLanguageCodes = SUPPORTED_LANGUAGES.map(lang => lang.code);

const chatRequestSchema = z.object({
  message: z.string().min(1, "Message cannot be empty"),
  language: z.enum(supportedLanguageCodes as [string, ...string[]]).default("en"),
  sessionId: z.string().optional(),
});

export async function registerRoutes(app: Express): Promise<Server> {
  app.post("/api/chat", async (req, res) => {
    try {
      const { message, language, sessionId } = chatRequestSchema.parse(req.body);
      
      const currentSessionId = sessionId || randomUUID();
      
      await storage.createChatMessage({
        sessionId: currentSessionId,
        role: "user",
        content: message,
        language,
      });
      
      const aiResponse = await getChatResponse(message, language);
      
      await storage.createChatMessage({
        sessionId: currentSessionId,
        role: "assistant",
        content: aiResponse,
        language,
      });
      
      res.json({
        response: aiResponse,
        sessionId: currentSessionId,
      });
    } catch (error) {
      console.error("Chat API error:", error);
      
      if (error instanceof z.ZodError) {
        return res.status(400).json({ 
          error: "Invalid request", 
          details: error.errors 
        });
      }
      
      res.status(500).json({ 
        error: "Failed to process chat message" 
      });
    }
  });

  app.get("/api/chat/history/:sessionId", async (req, res) => {
    try {
      const { sessionId } = req.params;
      const messages = await storage.getChatMessagesBySession(sessionId);
      res.json({ messages });
    } catch (error) {
      console.error("Chat history API error:", error);
      res.status(500).json({ 
        error: "Failed to retrieve chat history" 
      });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
